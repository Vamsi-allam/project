import { useState } from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import AdminDashboard from './Components/AdminDashboard'
import Atm from './Components/Atm'
import Atmtable from './Components/Atmtable'
import Temp from './Components/Temp'
import Side from './Components/Side'
import { Provider } from 'react-redux';
import store from './redux/store';
import ProtectedRoute from './Components/ProtectedRoute';
import SignIn from './Components/SignIn';

function App() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  return (
    <Provider store={store}>
      <Router>
        <Routes>
          <Route path="/login" element={<SignIn />} />
          <Route
            path="/*"
            element={
              <ProtectedRoute>
                <div style={{ display: 'flex' }}>
                  <Side onSidebarToggle={setIsSidebarOpen} />
                  <main style={{
                    marginLeft: isSidebarOpen ? '250px' : '60px',
                    width: `calc(100% - ${isSidebarOpen ? '250px' : '60px'})`,
                    transition: 'all 0.3s ease'
                  }}>
                    <Routes>
                      <Route path="dashboard" element={
                        <ProtectedRoute allowedRoles={['ADMIN']}>
                          <Atmtable />
                        </ProtectedRoute>
                      } />
                      <Route path="analytics" element={
                        <ProtectedRoute allowedRoles={['ADMIN', 'TECHNICIAN']}>
                          <Temp />
                        </ProtectedRoute>
                      } />
                      <Route path="logs" element={
                        <ProtectedRoute allowedRoles={['ADMIN']}>
                          <Atm />
                        </ProtectedRoute>
                      } />
                      <Route path="" element={
                        <Navigate to={
                          localStorage.getItem('role') === 'TECHNICIAN' 
                            ? 'analytics' 
                            : 'dashboard'
                        } replace />
                      } />
                    </Routes>
                  </main>
                </div>
              </ProtectedRoute>
            }
          />
        </Routes>
      </Router>
    </Provider>
  );
}

export default App;
