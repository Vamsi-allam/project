import React, { useEffect, useState } from "react";
import axios from "axios";
import { 
  FaThermometerHalf, 
  FaMoneyBillWave, 
  FaMapMarkerAlt, 
  FaBuilding, 
  FaUniversity  // Changed from FaAtm to FaUniversity for ATM icon
} from 'react-icons/fa';
import './Atmtable.css';

const Atmtable = () => {
  const [data, setData] = useState([]);
  const token = localStorage.getItem('token');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get("http://localhost:2003/locations", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        console.log(response.data);
        setData(response.data);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);

  const flattenData = () => {
    let rows = [];

    data.forEach((location) => {
      if (!location.branches?.length) {
        rows.push({
          location: location.name,
          branch: "N/A",
          atm: "N/A",
          temperature: "N/A",
          cash100: "N/A",
          cash200: "N/A",
          cash500: "N/A",
          totalCash: "N/A",
          recordedAt: "N/A",
        });
      } else {
        location.branches.forEach((branch) => {
          if (!branch.atms?.length) {
            rows.push({
              location: location.name,
              branch: branch.branchName || "N/A",
              atm: "N/A",
              temperature: "N/A",
              cash100: "N/A",
              cash200: "N/A",
              cash500: "N/A",
              totalCash: "N/A",
              recordedAt: "N/A",
            });
          } else {
            branch.atms.forEach((atm) => {
              atm.temp?.forEach((temp) => {
                atm.cash?.forEach((cash) => {
                  const totalCash =
                    (cash.cash100 || 0) * 100 + (cash.cash200 || 0) * 200 + (cash.cash500 || 0) * 500;

                  rows.push({
                    location: location.name,
                    branch: branch.branchName || "N/A",
                    atm: atm.atmCode || "N/A",
                    temperature: temp.temperature || "N/A",
                    cash100: cash.cash100 || 0,
                    cash200: cash.cash200 || 0,
                    cash500: cash.cash500 || 0,
                    totalCash: totalCash,
                    recordedAt: temp.updatedAt || cash.updatedAt || "N/A",
                  });
                });
              });
            });
          }
        });
      }
    });

    return rows;
  };

  const getRowClassName = (temperature) => {
    return parseFloat(temperature) > 30 ? 'high-temperature' : '';
  };

  return (
    <div className="table-container">
      <h2 className="table-title">
        <FaUniversity className="header-icon" /> ATM Monitoring Dashboard
      </h2>
      <div className="table-wrapper">
        <table className="custom-table">
          <thead>
            <tr>
              <th><FaMapMarkerAlt /> Location</th>
              <th><FaBuilding /> Branch</th>
              <th><FaUniversity /> ATM</th>
              <th><FaThermometerHalf /> Temperature</th>
              <th colSpan="4" className="cash-header">
                <FaMoneyBillWave /> Cash Details
              </th>
              <th>Last Updated</th>
            </tr>
            <tr>
              <th colSpan="3"></th>
              <th></th>
              <th>₹100</th>
              <th>₹200</th>
              <th>₹500</th>
              <th>Total</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {flattenData().map((row, index) => (
              <tr key={index} className={getRowClassName(row.temperature)}>
                <td>{row.location}</td>
                <td>{row.branch}</td>
                <td>{row.atm}</td>
                <td className="temperature-cell">
                  {row.temperature !== "N/A" ? 
                    `${row.temperature}°C` : "N/A"}
                </td>
                <td className="cash-cell">{row.cash100}</td>
                <td className="cash-cell">{row.cash200}</td>
                <td className="cash-cell">{row.cash500}</td>
                <td className="total-cash">₹{row.totalCash}</td>
                <td>{new Date(row.recordedAt).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Atmtable;