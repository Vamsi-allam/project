import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function AdminDashboard() {
  const navigate = useNavigate();
  const [locations, setLocations] = useState([]);
  const [branches, setBranches] = useState([]);
  const [atms, setAtms] = useState([]);
  const [selectedLocation, setSelectedLocation] = useState('');
  const [selectedBranch, setSelectedBranch] = useState('');

  useEffect(() => {
    const token = localStorage.getItem('token');
    const userRole = localStorage.getItem('userRole');
    
    if (!token || userRole !== 'ADMIN') {
      navigate('/login');
      return;
    }

    const fetchLocations = async () => {
      try {
        const response = await axios.get('http://localhost:2003/locations', {
          headers: {
            Authorization: `Bearer ${token}`
          }
        });
        setLocations(response.data);
        console.log(response.data);
      } catch (error) {
        console.error('Error fetching locations:', error);
      }
    };

    fetchLocations();
  }, [navigate]);

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (selectedLocation) {
      console.log(selectedLocation);
      const fetchBranches = async () => {
        try {
          const response = await axios.get(`http://localhost:2003/locations/${selectedLocation}`, {
            headers: {
              Authorization: `Bearer ${token}`
            }
          });
          console.log('Branches response:', response.data); // Add this line to log the response data
          if (response.data && Array.isArray(response.data.branches)) {
            setBranches(response.data.branches);
          } else {
            console.error('Expected an array but got:', response.data);
          }
        } catch (error) {
          console.error('Error fetching branches:', error);
        }
      };

      fetchBranches();
    } else {
      setBranches([]);
    }
  }, [selectedLocation]);

  useEffect(() => {
    if (selectedBranch) {
      const branch = branches.find(branch => branch.branchId === parseInt(selectedBranch));
      console.log(branch);
      setAtms(branch ? branch.atms : []);
    } else {
      setAtms([]);
    }
  }, [selectedBranch, branches]);

  const handleLocationChange = (event) => {
    setSelectedLocation(event.target.value);
    setSelectedBranch('');
    setAtms([]);
  };

  const handleBranchChange = (event) => {
    setSelectedBranch(event.target.value);
  };

  return (
    <div>
      <h1>Admin Dashboard</h1>
      <label htmlFor="locationDropdown">Select Location:</label>
      <select id="locationDropdown" value={selectedLocation} onChange={handleLocationChange}>
        <option value="">--Select a location--</option>
        {locations.map(location => (
          <option key={location.locationId} value={location.locationId}>{location.name}</option>
        ))}
      </select>

      {selectedLocation && branches.length > 0 && (
        <>
          <label htmlFor="branchDropdown">Select Branch:</label>
          <select id="branchDropdown" value={selectedBranch} onChange={handleBranchChange}>
            <option value="">--Select a branch--</option>
            {branches.map(branch => (
              <option key={branch.branchId} value={branch.branchId}>{branch.branchName || 'Unnamed Branch'}</option>
            ))}
          </select>

          <div>
            <h2>Branch Details</h2>
            <table>
              <thead>
                <tr>
                  <th>Branch ID</th>
                  <th>Branch Name</th>
                  <th>Location ID</th>
                </tr>
              </thead>
              <tbody>
                {branches.map(branch => (
                  <tr key={branch.branchId}>
                    <td>{branch.branchId}</td>
                    <td>{branch.branchName || 'Unnamed Branch'}</td>
                    <td>{branch.locationId}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}

      {selectedBranch && atms.length > 0 && (
        <table>
          <thead>
            <tr>
              <th>ATM Code</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {atms.map(atm => (
              <tr key={atm.atmCode}>
                <td>{atm.atmCode}</td>
                <td>{atm.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

export default AdminDashboard;