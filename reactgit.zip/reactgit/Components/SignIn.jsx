import React, { useState, useEffect } from "react";

import { useNavigate } from "react-router-dom";

import { ToastContainer, toast } from "react-toastify";

import "react-toastify/dist/ReactToastify.css"; // Import Toastify CSS

import "./SignIn.css";



const SignIn = () => {

 useEffect(() => {

  document.body.style.margin = "0";

  document.body.style.overflow = "hidden";

  document.documentElement.style.overflow = "hidden";

  return () => {

   document.body.style.margin = "";

   document.body.style.overflow = "";

   document.documentElement.style.overflow = "";

  };

 }, []);



 const [emailOrPhone, setEmailOrPhone] = useState("");

 const [password, setPassword] = useState("");

 const [showPassword, setShowPassword] = useState(false);

 const navigate = useNavigate();



 const handleSubmit = async (e) => {

  e.preventDefault();

  try {

   const response = await fetch("http://localhost:8080/api/login", {

    method: "POST",

    headers: {

     "Content-Type": "application/json",

    },

    body: JSON.stringify({ emailOrPhone, password }),

   });



   const data = await response.json();



   if (response.ok) {

    switch (data.role) {

     case "ADMIN":

      toast.success("Successful login as Admin!", {

       style: { backgroundColor: "#38a169", color: "white" }, // Green color

      });

      setTimeout(() => navigate("/adminpage"), 2000);

      break;

     case "TECHNICIAN":

      toast.success("Successful login as Technician!", {

       style: { backgroundColor: "#38a169", color: "white" }, // Green color

      });

      setTimeout(() => navigate("/technicianpage"), 2000);

      break;

     default:

      toast.success("Successful login!", {

       style: { backgroundColor: "#38a169", color: "white" }, // Green color

      });

      setTimeout(() => navigate("/homepage"), 2000);

    }

   } else {

    if (data.message === "Usernotfound") {

     toast.error("User not found!", {

      style: { backgroundColor: "#e53e3e", color: "white" }, // Red color

     });

    } else if (data.message === "Invalidpassword") {

     toast.error("Invalid password!", {

      style: { backgroundColor: "#dd6b20", color: "white" }, // Orange color

     });

    } else {

     toast.error("Invalid credentials!", {

      style: { backgroundColor: "#e53e3e", color: "white" }, // Red color

     });

    }

   }

  } catch (error) {

   toast.error("Error connecting to the server.", {

    style: { backgroundColor: "#e53e3e", color: "white" }, // Red color

   });

   console.error("Error:", error);

  }

 };



 const handleForgotPassword = () => {

  navigate("/forgot-password");

 };



 return (

  <>

   <nav className="navbar">

    <div className="nav-left">ATM-MONITORING</div>

    <div className="nav-right">

     <button className="nav-button" onClick={() => navigate("/")}>

      Homepage

     </button>

     <button className="nav-button" onClick={() => navigate("/register")}>

      Register

     </button>

    </div>

   </nav>

   <div className="container">

    <div className="login-box">

     <div className="header">

      <h2 className="heading">Welcome Back!</h2>

      <p className="sub-heading">Sign in to access your account</p>

     </div>

     <form onSubmit={handleSubmit} className="form">

      <div className="input-container">

       <label className="label">Email / Phone Number</label>

       <input

        type="text"

        placeholder="Enter Email or Phone Number"

        value={emailOrPhone}

        onChange={(e) => setEmailOrPhone(e.target.value)}

        required

        className="input"

       />

      </div>

      <div className="input-container">

       <div className="password-label-container">

        <label className="label">Password</label>

        <span className="forgot-password" onClick={handleForgotPassword}>

         Forgot password?

        </span>

       </div>

       <input

        type={showPassword ? "text" : "password"}

        placeholder="Enter Password"

        value={password}

        onChange={(e) => setPassword(e.target.value)}

        required

        className="input"

       />

       <div className="checkbox-container">

        <label className="checkbox-label">

         <input

          type="checkbox"

          checked={showPassword}

          onChange={(e) => setShowPassword(e.target.checked)}

          className="checkbox"

         />{" "}

         Show Password

        </label>

       </div>

      </div>

      <button type="submit" className="button">

       Sign In

      </button>

     </form>

     <div className="register-container">

      <p className="register-text">

       Not a user?{" "}

       <span className="register-link" onClick={() => navigate("/register")}>

        Register here

       </span>

      </p>

     </div>

    </div>

   </div>

   <ToastContainer position="bottom-right" autoClose={2000} pauseOnHover theme="colored" />

  </>

 );

};



export default SignIn;

