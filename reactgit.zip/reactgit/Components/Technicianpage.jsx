import React from 'react'

const Technicianpage = () => {
    return (
        <div>
            <h1>welcome to the technician dashboard</h1>
        </div>
    )
};

export default Technicianpage
