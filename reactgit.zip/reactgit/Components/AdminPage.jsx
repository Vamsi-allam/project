import React from 'react'

const AdminPage = () => {
    return (
        <div>
            <h1>welcome to the admin dashboard</h1>
        </div>
    )
};
export default AdminPage
