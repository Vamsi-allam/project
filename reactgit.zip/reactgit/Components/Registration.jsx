import React, { useState, useEffect } from "react";

import { useNavigate } from "react-router-dom";

import { toast, ToastContainer } from "react-toastify";

import "react-toastify/dist/ReactToastify.css";

import "./Registration.css"; // CSS file import



const Registration = () => {

  useEffect(() => {

    // Fix page: no scrolling and zero margin

    document.body.style.margin = "0";

    document.body.style.overflow = "hidden";

    return () => {

      document.body.style.margin = "";

      document.body.style.overflow = "";

    };

  }, []);



  const [name, setName] = useState("");

  const [email, setEmail] = useState("");

  const [phoneNumber, setPhoneNumber] = useState("");

  const [password, setPassword] = useState("");

  const [confirmPassword, setConfirmPassword] = useState("");

  const [role, setRole] = useState("");

  const [showPassword, setShowPassword] = useState(false);

  const [emailError, setEmailError] = useState("");

  const [phoneError, setPhoneError] = useState("");

  const [passwordError, setPasswordError] = useState("");

  const [confirmPasswordError, setConfirmPasswordError] = useState("");



  const navigate = useNavigate();



  const validateEmail = () => {

    if (!email.includes("@")) {

      setEmailError("Invalid email address");

    } else {

      setEmailError("");

    }

  };



  const validatePhoneNumber = () => {

    const phoneRegex = /^[0-9]{10}$/;

    if (!phoneRegex.test(phoneNumber)) {

      setPhoneError("Phone number must be 10 digits");

    } else {

      setPhoneError("");

    }

  };



  const validatePassword = () => {

    const passwordRegex =

      /^(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{4,12}$/;

    if (!passwordRegex.test(password)) {

      setPasswordError(

        "Password must be 4-12 characters, include at least one capital letter, one number, and one special character."

      );

    } else {

      setPasswordError("");

    }

  };



  const validateConfirmPassword = () => {

    if (password !== confirmPassword) {

      setConfirmPasswordError("Passwords do not match");

    } else {

      setConfirmPasswordError("");

    }

  };



  const handleSubmit = async (e) => {

    e.preventDefault();

    validateEmail();

    validatePhoneNumber();

    validatePassword();

    validateConfirmPassword();



    if (emailError || phoneError || passwordError || confirmPasswordError) {

      return;

    }



    try {

      const response = await fetch("http://localhost:8080/api/register", {

        method: "POST",

        headers: {

          "Content-Type": "application/json",

        },

        body: JSON.stringify({

          name,

          email,

          phoneNumber,

          password,

          role,

        }),

      });



      const isJson = response.headers.get("content-type")?.includes("application/json");



      if (response.ok) {

        const data = isJson ? await response.json() : await response.text();

        toast.success(`${data.message || "Registration successful!"} as ${role}`);

        setTimeout(() => {

          toast.info("Navigating to login...");

          setTimeout(() => navigate("/login"), 2000);

        }, 2000);

      } else {

        const errorData = isJson ? await response.json() : await response.text();

        toast.error(errorData.error || "Registration failed.");

      }

    } catch (error) {

      console.error("Error:", error);

      toast.error("An error occurred. Please try again.");

    }

  };



  return (

    <>

      <div className="reg-container">

        {/* Navigation Bar */}

        <nav className="reg-navbar">

          <div className="reg-brand">ATM-MONITORING</div>

          <div className="reg-nav-buttons">

            <button onClick={() => navigate("/")} className="reg-nav-button">

              HomePage

            </button>

            <button onClick={() => navigate("/login")} className="reg-nav-button">

              Login

            </button>

          </div>

        </nav>



        <div className="reg-box">

          <div className="reg-header">

            <h2 className="reg-heading">Welcome!</h2>

            <p className="reg-subheading">Register here to access the account</p>

          </div>

          <form onSubmit={handleSubmit} className="reg-form">

            {/* Name and Email Fields Side by Side */}

            <div className="reg-row">

              <div className="reg-input-container">

                <label className="reg-label">Name</label>

                <input

                  type="text"

                  placeholder="Enter your name"

                  value={name}

                  onChange={(e) => setName(e.target.value)}

                  required

                  className="reg-input"

                />

              </div>

              <div className="reg-input-container">

                <label className="reg-label">Email</label>

                <input

                  type="email"

                  placeholder="name@example.com"

                  value={email}

                  onChange={(e) => setEmail(e.target.value)}

                  onBlur={validateEmail}

                  required

                  className="reg-input"

                />

                {emailError && <p className="reg-error">{emailError}</p>}

              </div>

            </div>



            {/* Phone Number Field */}

            <div className="reg-input-container">

              <label className="reg-label">Phone Number</label>

              <input

                type="text"

                placeholder="Enter your phone number"

                value={phoneNumber}

                onChange={(e) => setPhoneNumber(e.target.value)}

                onBlur={validatePhoneNumber}

                required

                className="reg-input"

              />

              {phoneError && <p className="reg-error">{phoneError}</p>}

            </div>



            {/* Password and Confirm Password Side by Side */}

            <div className="reg-row">

              <div className="reg-input-container">

                <label className="reg-label">Password</label>

                <input

                  type={showPassword ? "text" : "password"}

                  placeholder="Enter password"

                  value={password}

                  onChange={(e) => setPassword(e.target.value)}

                  onBlur={validatePassword}

                  required

                  className="reg-input"

                />

                {passwordError && <p className="reg-error">{passwordError}</p>}

              </div>

              <div className="reg-input-container">

                <label className="reg-label">Confirm Password</label>

                <input

                  type={showPassword ? "text" : "password"}

                  placeholder="Confirm password"

                  value={confirmPassword}

                  onChange={(e) => setConfirmPassword(e.target.value)}

                  onBlur={validateConfirmPassword}

                  required

                  className="reg-input"

                />

                {confirmPasswordError && <p className="reg-error">{confirmPasswordError}</p>}

              </div>

            </div>



            {/* Show Password Checkbox */}

            <div className="reg-show-password-container">

              <label className="reg-show-password-label">

                <input

                  type="checkbox"

                  checked={showPassword}

                  onChange={() => setShowPassword(!showPassword)}

                  className="reg-checkbox"

                />

                Show Password

              </label>

            </div>



            {/* Role Selection */}

            <div className="reg-input-container">

              <label className="reg-label">Role</label>

              <div className="reg-radio-container">

                <label className="reg-radio-label">

                  <input

                    type="radio"

                    name="role"

                    value="ADMIN"

                    onChange={(e) => setRole(e.target.value)}

                    required

                    className="reg-radio-button"

                  />

                  Admin

                </label>

                <label className="reg-radio-label">

                  <input

                    type="radio"

                    name="role"

                    value="TECHNICIAN"

                    onChange={(e) => setRole(e.target.value)}

                    required

                    className="reg-radio-button"

                  />

                  Technician

                </label>

              </div>

            </div>



            {/* Register Button */}

            <button type="submit" className="reg-button">

              Register

            </button>

          </form>



          {/* Already Have an Account */}

          <p className="reg-already-text">

            Already have an account?{" "}

            <span className="reg-link" onClick={() => navigate("/login")}>

              Login here

            </span>

          </p>

        </div>

        <ToastContainer position="bottom-right" />

      </div>

    </>

  );

};



export default Registration;

