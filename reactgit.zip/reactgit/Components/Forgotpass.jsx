import React, { useState } from "react";

import { useNavigate } from "react-router-dom";

const ForgotPass = () => {

 const [phoneNumber, setPhoneNumber] = useState("");

 const [otp, setOtp] = useState("");

 const [newPassword, setNewPassword] = useState("");

 const [step, setStep] = useState(1); // Steps: 1 = Request OTP, 2 = Verify OTP and Reset Password

 const [errorMessage, setErrorMessage] = useState("");

 const navigate = useNavigate();

 const requestOtp = async () => {

  try {

   const response = await fetch("http://localhost:8080/api/forgot-password/request-otp", {

    method: "POST",

    headers: {

     "Content-Type": "application/json",

    },

    body: JSON.stringify({ phoneNumber }),

   });

   if (response.ok) {

    alert("OTP sent to your phone number.");

    setStep(2); // Move to the next step

   } else {

    const data = await response.json();

    setErrorMessage(data.message || "Failed to send OTP. Please try again.");

   }

  } catch {

   setErrorMessage("Error connecting to the server.");

  }

 };

 const verifyOtpAndResetPassword = async () => {

  try {

   const response = await fetch("http://localhost:8080/api/forgot-password/verify-otp", {

    method: "POST",

    headers: {

     "Content-Type": "application/json",

    },

    body: JSON.stringify({ phoneNumber, otp, newPassword }),

   });

   if (response.ok) {

    alert("Password reset successfully! Please login with your new password.");

    navigate("/signin"); // Redirect to the sign-in page

   } else {

    const data = await response.json();

    setErrorMessage(data.message || "Failed to reset password. Please try again.");

   }

  } catch {

   setErrorMessage("Error connecting to the server.");

  }

 };

 return (

  <div style={styles.container}>

   <div style={styles.formContainer}>

    <h2 style={styles.heading}>Forgot Password</h2>

    {step === 1 && (

     <>

      <p style={styles.subHeading}>Enter your phone number to receive an OTP</p>

      <input

       type="text"

       placeholder="Phone Number"

       value={phoneNumber}

       onChange={(e) => setPhoneNumber(e.target.value)}

       style={styles.input}

      />

      <button onClick={requestOtp} style={styles.button}>

       Request OTP

      </button>

     </>

    )}

    {step === 2 && (

     <>

      <p style={styles.subHeading}>Enter the OTP and your new password</p>

      <input

       type="text"

       placeholder="Enter OTP"

       value={otp}

       onChange={(e) => setOtp(e.target.value)}

       style={styles.input}

      />

      <input

       type="password"

       placeholder="New Password"

       value={newPassword}

       onChange={(e) => setNewPassword(e.target.value)}

       style={styles.input}

      />

      <button onClick={verifyOtpAndResetPassword} style={styles.button}>

       Reset Password

      </button>

     </>

    )}

    {errorMessage && <p style={styles.errorMessage}>{errorMessage}</p>}

   </div>

  </div>

 );

};

// Inline styles

const styles = {

 container: {

  height: "100vh",

  display: "flex",

  justifyContent: "center",

  alignItems: "center",

  backgroundColor: "#f5f5f5",

  fontFamily: "Arial, sans-serif",

 },

 formContainer: {

  width: "400px",

  background: "white",

  padding: "20px",

  borderRadius: "10px",

  boxShadow: "0px 4px 10px rgba(0, 0, 0, 0.1)",

  textAlign: "center",

 },

 heading: {

  fontSize: "20px",

  marginBottom: "15px",

 },

 subHeading: {

  fontSize: "14px",

  color: "#6b7280",

  marginBottom: "15px",

 },

 input: {

  width: "100%",

  padding: "10px",

  marginBottom: "15px",

  border: "1px solid #ddd",

  borderRadius: "5px",

  boxSizing: "border-box",

 },

 button: {

  width: "100%",

  padding: "10px",

  background: "#9333ea",

  color: "white",

  border: "none",

  borderRadius: "5px",

  cursor: "pointer",

  fontSize: "16px",

 },

 errorMessage: {

  color: "red",

  fontSize: "14px",

  marginTop: "10px",

 },

};

export default ForgotPass;
