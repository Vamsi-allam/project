import React, { useEffect } from "react";

import { useNavigate } from "react-router-dom";

import "./HomePage.css"; // Import the unique CSS
const HomePage = () =>{

  useEffect(() => {

    document.body.style.margin = "0";

    return () => {

      document.body.style.margin = "";

    };

  }, []);



  const navigate = useNavigate();



  const handleLogin = () => {

    navigate("/login");

  };



  const handleRegister = () => {

    navigate("/register");

  };



  const teamMembers = [

    { name: "Vamsi Allam", employeeId: "EMP1001" },

    { name: "Vignesh", employeeId: "EMP1002" },

    { name: "Vamshidhar Jogula", employeeId: "EMP1003" },

    { name: "Priya Patel", employeeId: "EMP1004" },

    { name: "David Rodriguez", employeeId: "EMP1005" },

  ];



  return (

    <div className="home-app">

      {/* Navigation Bar */}

      <nav className="home-navbar">

        <div className="home-nav-links">

          <a href="#welcome" className="home-nav-link">

            Welcome

          </a>

          <a href="#overview" className="home-nav-link">

            Project Overview

          </a>

          <a href="#team" className="home-nav-link">

            Team Members

          </a>

        </div>

        <div className="home-nav-buttons">

          <button onClick={handleLogin} className="home-nav-button">

            Login

          </button>

          <button onClick={handleRegister} className="home-nav-button">

            Register

          </button>

        </div>

      </nav>



      {/* Welcome Section: occupies full viewport height */}

      <section id="welcome" className="home-section">

        <div className="home-section-content">

          <h1 className="home-title">Welcome to ATM Monitoring</h1>

          <p className="home-subtitle">

            Ensuring your transactions are secure and efficient.

          </p>

        </div>

      </section>



      {/* Project Overview Section: occupies full viewport height */}

      <section id="overview" className="home-section">

        <div className="home-section-content">

          <h2 className="home-section-title">Project Overview</h2>

          <p className="home-section-text">

            Our ATM Monitoring System provides real-time insights into machine

            performance, ensuring maximum uptime and efficient operation.

          </p>

        </div>

      </section>



      {/* Team Members Section: occupies full viewport height */}

      <section id="team" className="home-section">

        <div className="home-section-content">

          <h2 className="home-section-title">Team Members</h2>

          <div className="home-team-container">

            {teamMembers.map((member, index) => (

              <div key={index} className="home-team-card">

                <h3 className="home-team-name">{member.name}</h3>

                <p className="home-team-id">Employee ID: {member.employeeId}</p>

              </div>

            ))}

          </div>

        </div>

      </section>

    </div>

  );

}
export default HomePage;
