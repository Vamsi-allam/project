import React from "react";

import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import SignIn from "./Components/signin.jsx";

import Registration from "./Components/Registration.jsx";
import AdminPage from "./Components/AdminPage.jsx";
import Technicianpage from "./Components/Technicianpage.jsx";
import Forgotpass from "./Components/Forgotpass.jsx";
import HomePage from "./Components/Homepage.jsx";
function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} />

        {/* Route for SignIn */}
        <Route path="/login" element={<SignIn />} />
        {/* Route for Register */}

        <Route path="/register" element={<Registration />} />
        <Route path="/adminpage"element={<AdminPage/>}/>
        <Route path="/technicianpage"element={<Technicianpage/>}/>
        <Route path="/forgot-password"element={<Forgotpass/>}/>

        {/* Default Route (redirect to login) */}

        <Route path="*" element={<HomePage />} />

      </Routes>

    </Router>

  );

}
export default App;