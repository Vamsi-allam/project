package com.university.exam.service;

import com.university.exam.dto.InvigilatorDTO;
import com.university.exam.entity.Invigilator;
import com.university.exam.repository.InvigilatorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class InvigilatorService {

    @Autowired
    private InvigilatorRepository invigilatorRepository;

    public InvigilatorDTO createInvigilator(InvigilatorDTO dto) {
        Invigilator invigilator = new Invigilator();
        invigilator.setFullName(dto.getFullName());
        invigilator.setContactInfo(dto.getContactInfo());

        Invigilator saved = invigilatorRepository.save(invigilator);
        return toDTO(saved);
    }

    public InvigilatorDTO getInvigilatorById(Long id) {
        Invigilator inv = invigilatorRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Invigilator not found with id " + id));
        return toDTO(inv);
    }

    public List<InvigilatorDTO> getAllInvigilators() {
        return invigilatorRepository.findAll().stream()
            .map(this::toDTO)
            .collect(Collectors.toList());
    }

    public InvigilatorDTO updateInvigilator(Long id, InvigilatorDTO dto) {
        Invigilator inv = invigilatorRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Invigilator not found with id " + id));

        inv.setFullName(dto.getFullName());
        inv.setContactInfo(dto.getContactInfo());

        Invigilator updated = invigilatorRepository.save(inv);
        return toDTO(updated);
    }

    public void deleteInvigilator(Long id) {
        invigilatorRepository.deleteById(id);
    }

    private InvigilatorDTO toDTO(Invigilator inv) {
        return new InvigilatorDTO(
            inv.getId(),
            inv.getFullName(),
            inv.getContactInfo()
        );
    }
}
