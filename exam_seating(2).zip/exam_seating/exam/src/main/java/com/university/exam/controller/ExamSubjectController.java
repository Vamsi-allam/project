package com.university.exam.controller;

import com.university.exam.dto.ExamSubjectDTO;
import com.university.exam.service.ExamSubjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/exam-subjects")
@CrossOrigin(origins = "*")
public class ExamSubjectController {

    @Autowired
    private ExamSubjectService examSubjectService;

    @PostMapping
    public ResponseEntity<ExamSubjectDTO> create(@RequestBody ExamSubjectDTO dto) {
        return ResponseEntity.ok(examSubjectService.createExamSubject(dto));
    }

    @GetMapping
    public ResponseEntity<List<ExamSubjectDTO>> getAll() {
        return ResponseEntity.ok(examSubjectService.getAllExamSubjects());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ExamSubjectDTO> getById(@PathVariable Long id) {
        return ResponseEntity.ok(examSubjectService.getExamSubjectById(id));
    }

    @GetMapping("/exam/{examId}")
    public ResponseEntity<List<ExamSubjectDTO>> getByExamId(@PathVariable Long examId) {
        return ResponseEntity.ok(examSubjectService.getByExamId(examId));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ExamSubjectDTO> update(@PathVariable Long id, @RequestBody ExamSubjectDTO dto) {
        return ResponseEntity.ok(examSubjectService.updateExamSubject(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        examSubjectService.deleteExamSubject(id);
        return ResponseEntity.noContent().build();
    }
}
