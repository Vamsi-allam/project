package com.university.exam.service;

import com.university.exam.dto.*;
import com.university.exam.entity.*;
import com.university.exam.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@Transactional
public class SeatingPlanService {

    @Autowired private SeatingPlanRepository seatingPlanRepo;
    @Autowired private ExamRepository examRepo;
    @Autowired private BlockRepository blockRepo;
    @Autowired private AdminRepository adminRepo;
    @Autowired private SectionRepository sectionRepo;
    @Autowired private StudentRepository studentRepo;
    @Autowired private RoomRepository roomRepo;
    @Autowired private SeatAssignmentRepository seatAssignmentRepo;
    @Autowired private PlanRoomInvigilatorRepository planRoomInvRepo;
    @Autowired private InvigilatorRepository invigilatorRepo;
    @Autowired private RoomAllocationService roomAllocationService;

    // Create Seating Plan
    public SeatingPlanDTO createPlan(CreatePlanRequest req) {
        Exam exam = examRepo.findById(req.getExamId())
                .orElseThrow(() -> new IllegalArgumentException("Exam not found"));
        Block block = blockRepo.findById(req.getBlockId().intValue())
                .orElseThrow(() -> new IllegalArgumentException("Block not found"));

        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        Admin admin = adminRepo.findByEmail(username)
                .orElseThrow(() -> new IllegalArgumentException("Admin not found"));

        SeatingPlan plan = new SeatingPlan();
        plan.setExam(exam);
        plan.setBlock(block);
        plan.setAdmin(admin);

        // Set selected sections
        List<Section> sections = sectionRepo.findAllById(
            req.getSectionIds().stream().map(Long::intValue).collect(Collectors.toList())
        );
        plan.setSections(sections);

        seatingPlanRepo.save(plan);

        // Allocate rooms based on student count
        Map<Long, Integer> counts = req.getSectionIds().stream()
                .collect(Collectors.toMap(
                        sid -> sid,
                        sid -> studentRepo.countBySectionId(sid)
                ));
        List<Room> rooms = roomAllocationService.allocateRooms(block.getId(), counts);
        plan.setRooms(rooms);
        seatingPlanRepo.save(plan);

        return toDTO(plan);
    }

    // Update rooms
    public SeatingPlanDTO updateRooms(Long planId, RoomAdjustmentRequest req) {
        SeatingPlan plan = seatingPlanRepo.findById(planId)
                .orElseThrow(() -> new IllegalArgumentException("Plan not found"));

        plan.setRooms(roomRepo.findAllById(req.getRoomIds()));
        seatingPlanRepo.save(plan);

        return toDTO(plan);
    }

    // Finalize plan
    public SeatingPlanDTO finalizePlan(Long planId, List<InvigilatorAssignment> invs) {
        SeatingPlan plan = seatingPlanRepo.findById(planId)
                .orElseThrow(() -> new IllegalArgumentException("Plan not found"));

        seatAssignmentRepo.deleteBySeatingPlanId(planId);
        planRoomInvRepo.deleteBySeatingPlanId(planId);

        for (InvigilatorAssignment a : invs) {
            Invigilator inv = invigilatorRepo.findById(a.getInvigilatorId())
                    .orElseThrow(() -> new IllegalArgumentException("Invigilator not found"));
            Room room = roomRepo.getReferenceById(a.getRoomId());
            planRoomInvRepo.save(new PlanRoomInvigilator(plan, room, inv));
        }

        List<Section> sections = plan.getSections();
        List<Student> students = sections.stream()
                .flatMap(sec -> studentRepo.findBySectionId(Long.valueOf(sec.getId())).stream())
                .collect(Collectors.toList());

        List<SeatAssignment> assignments = roomAllocationService.assignSeats(plan, students);
        seatAssignmentRepo.saveAll(assignments);

        return toDTO(plan);
    }

    // Regenerate plan
    public SeatingPlanDTO regeneratePlan(Long planId) {
        seatAssignmentRepo.deleteBySeatingPlanId(planId);
        planRoomInvRepo.deleteBySeatingPlanId(planId);

        List<InvigilatorAssignment> prev = planRoomInvRepo.findBySeatingPlanId(planId).stream()
                .map(pi -> new InvigilatorAssignment(pi.getRoom().getId(), pi.getInvigilator().getId()))
                .collect(Collectors.toList());

        return finalizePlan(planId, prev);
    }

    // Get plan
    @Transactional(readOnly = true)
    public SeatingPlanDTO getPlan(Long planId) {
        SeatingPlan plan = seatingPlanRepo.findById(planId)
                .orElseThrow(() -> new IllegalArgumentException("Plan not found"));
        return toDTO(plan);
    }

    // Delete plan
    public void deletePlan(Long planId) {
        seatingPlanRepo.deleteById(planId);
    }

    // Mapping entity to DTO
    private SeatingPlanDTO toDTO(SeatingPlan plan) {
        return new SeatingPlanDTO(
            plan.getId(),
            plan.getExam().getId(),
            plan.getBlock().getId().longValue(),
            plan.getAdmin().getId(),
            plan.getCreatedAt(),
            plan.getRooms().stream().map(Room::getId).collect(Collectors.toList()),
            plan.getSections().stream().map(section -> Long.valueOf(section.getId())).collect(Collectors.toList())
        );
    }
    public List<SeatAssignmentDTO> getSeatAssignmentsByPlanId(Long planId) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getSeatAssignmentsByPlanId'");
    }
}
