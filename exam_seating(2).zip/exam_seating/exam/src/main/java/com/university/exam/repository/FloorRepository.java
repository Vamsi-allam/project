package com.university.exam.repository;

import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.university.exam.entity.Floor;
import java.util.List;
@Repository
public interface FloorRepository extends JpaRepository<Floor, Integer> {
    List<Floor> findByBlockId(Integer blockId);
}
