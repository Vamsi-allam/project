package com.university.exam.repository;

import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.university.exam.entity.SeatAssignment;
import java.util.List;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.jpa.repository.Query;
@Repository

public interface SeatAssignmentRepository extends JpaRepository<SeatAssignment, Long> {
    List<SeatAssignment> findBySeatingPlanId(Long seatingPlanId);
    @Modifying
    @Transactional
    @Query("DELETE FROM SeatAssignment sa WHERE sa.seatingPlan.id = :planId")
    void deleteBySeatingPlanId(Long planId);
}
