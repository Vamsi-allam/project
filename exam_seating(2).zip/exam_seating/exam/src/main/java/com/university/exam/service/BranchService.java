package com.university.exam.service;

import com.university.exam.dto.BranchDTO;
import com.university.exam.entity.Branch;
import com.university.exam.entity.YearLevel;
import com.university.exam.repository.BranchRepository;
import com.university.exam.repository.YearLevelRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class BranchService {

    @Autowired
    private BranchRepository branchRepository;

    @Autowired
    private YearLevelRepository yearLevelRepository;

    public BranchDTO create(BranchDTO dto) {
        YearLevel yearLevel = getYearLevelById(dto.getYearId());
        Branch branch = new Branch(dto.getName(), yearLevel);
        return convertToDTO(branchRepository.save(branch));
    }

    public BranchDTO getById(Integer id) {
        Branch branch = branchRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Branch not found with id " + id));
        return convertToDTO(branch);
    }

    public List<BranchDTO> listAll() {
        return branchRepository.findAll()
                .stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public List<BranchDTO> getBranchesByYear(Integer yearId) {
        return branchRepository.findAll()
                .stream()
                .filter(branch -> branch.getYearLevel().getId().equals(yearId))
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public BranchDTO update(Integer id, BranchDTO dto) {
        Branch branch = branchRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Branch not found with id " + id));
        branch.setName(dto.getName());
        branch.setYearLevel(getYearLevelById(dto.getYearId()));
        return convertToDTO(branchRepository.save(branch));
    }

    public void delete(Integer id) {
        branchRepository.deleteById(id);
    }

    private YearLevel getYearLevelById(Integer yearId) {
        return yearLevelRepository.findById(yearId)
                .orElseThrow(() -> new IllegalArgumentException("YearLevel not found with id " + yearId));
    }

    private BranchDTO convertToDTO(Branch branch) {
        BranchDTO branchDTO = new BranchDTO();
        branchDTO.setId(branch.getId());
        branchDTO.setName(branch.getName());
        branchDTO.setYearId(branch.getYearLevel().getId());
        return branchDTO;
    }
}
