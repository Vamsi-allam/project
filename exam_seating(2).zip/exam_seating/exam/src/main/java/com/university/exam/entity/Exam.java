package com.university.exam.entity;

import jakarta.persistence.*;
import lombok.Data;
import java.sql.Time;
import java.util.Date;
@Entity
@Data
@Table(name = "exam")
public class Exam {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private Date examDate;
    private Time startTime;
    private Time endTime;
    
    public Exam(String name, Date examDate, Time startTime, Time endTime) {
        this.name = name;
        this.examDate = examDate;
        this.startTime = startTime;
        this.endTime = endTime;
    }
    public Exam(String name) {
        this.name = name;
    }
    public Exam() {
    }
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public Date getExamDate() {
        return examDate;
    }
    public void setExamDate(Date examDate) {
        this.examDate = examDate;
    }
    public Time getStartTime() {
        return startTime;
    }
    public void setStartTime(Time startTime) {
        this.startTime = startTime;
    }
    public Time getEndTime() {
        return endTime;
    }
    public void setEndTime(Time endTime) {
        this.endTime = endTime;
    }

}