package com.university.exam.service;

import com.university.exam.entity.Room;
import com.university.exam.repository.RoomRepository;
import com.university.exam.dto.RoomDTO;
import com.university.exam.entity.Floor; // Import the Floor class
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class RoomService {
    @Autowired
    private RoomRepository roomRepository;

    // Create Room
    public RoomDTO createRoom(RoomDTO roomDTO) {
        Room room = new Room();
        room.setName(roomDTO.getName());
        room.setRows(roomDTO.getRows());
        room.setCols(roomDTO.getCols());

        // Assume you have a Floor entity and mapping here
        // Set the floor if floorId is provided
        if (roomDTO.getFloorId() != null) {
            room.setFloor(new Floor(roomDTO.getFloorId()));  // Assuming Floor constructor with ID
        }

        room = roomRepository.save(room);
        return toDTO(room);
    }

    // Get Room by ID
    public RoomDTO getRoomById(Long id) {
        Room room = roomRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Room not found with id " + id));
        return toDTO(room);
    }

    // Get All Rooms
    public List<RoomDTO> getAllRooms() {
        List<Room> rooms = roomRepository.findAll();
        return rooms.stream().map(this::toDTO).collect(Collectors.toList());
    }

    // Get Rooms by Floor
    public List<RoomDTO> getRoomsByFloor(Integer floorId) {
        List<Room> rooms = roomRepository.findByFloorId(floorId);
        return rooms.stream().map(this::toDTO).collect(Collectors.toList());
    }

    // Get Rooms by Block
    public List<RoomDTO> getRoomsByBlock(Integer blockId) {
        List<Room> rooms = roomRepository.findByBlockId(blockId);
        return rooms.stream().map(this::toDTO).collect(Collectors.toList());
    }

    // Update Room
    public RoomDTO updateRoom(Long id, RoomDTO roomDTO) {
        Room room = roomRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Room not found with id " + id));
        
        room.setName(roomDTO.getName());
        room.setRows(roomDTO.getRows());
        room.setCols(roomDTO.getCols());

        // Set floor if floorId is provided
        if (roomDTO.getFloorId() != null) {
            room.setFloor(new Floor(roomDTO.getFloorId())); // Assuming Floor constructor with ID
        }

        room = roomRepository.save(room);
        return toDTO(room);
    }

    // Delete Room
    public void deleteRoom(Long id) {
        roomRepository.deleteById(id);
    }

    // Helper method to convert Room entity to RoomDTO
    private RoomDTO toDTO(Room room) {
        return new RoomDTO(
            room.getId(),
            room.getName(),
            room.getRows(),
            room.getCols(),
            room.getFloor() != null ? room.getFloor().getId() : null // Assuming Floor has getId() method
        );
    }
}
