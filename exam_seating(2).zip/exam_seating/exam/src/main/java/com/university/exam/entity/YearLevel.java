package com.university.exam.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "year_level")
public class YearLevel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String name;
    private String note;

    public YearLevel(String name, String note) {
        this.name = name;
        this.note = note;
    }
    public YearLevel(String name) {
        this.name = name;
    }
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public YearLevel() {}
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getNote() {
        return note;
    }
    public void setNote(String note) {
        this.note = note;
    }
}
