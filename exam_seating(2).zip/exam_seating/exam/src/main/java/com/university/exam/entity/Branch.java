package com.university.exam.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "branch")
public class Branch {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "year_id", nullable = false)
    private YearLevel yearLevel;
    private String name;

    public Branch(String name, YearLevel yearLevel) {
        this.name = name;
        this.yearLevel = yearLevel;
    }
    public Branch(String name) {
        this.name = name;
    }
    public Branch() {
    }
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public YearLevel getYearLevel() {
        return yearLevel;
    }
    public void setYearLevel(YearLevel yearLevel) {
        this.yearLevel = yearLevel;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    
}
