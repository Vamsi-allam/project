package com.university.exam.dto;

import lombok.*;

@Builder
public class SeatAssignmentDTO {
    private Long seatingPlanId;
    private Long roomId;
    private Long studentId;
    private String regNo;  // Added regNo field
    private Integer seatRow;
    private Integer seatCol;

    public SeatAssignmentDTO(Long seatingPlanId, Long roomId, Long studentId, String regNo, Integer seatRow, Integer seatCol) {
        this.seatingPlanId = seatingPlanId;
        this.roomId = roomId;
        this.studentId = studentId;
        this.regNo = regNo;
        this.seatRow = seatRow;
        this.seatCol = seatCol;
    }

    public SeatAssignmentDTO() {
    }

    // Getters and setters
    public Long getSeatingPlanId() {
        return seatingPlanId;
    }

    public void setSeatingPlanId(Long seatingPlanId) {
        this.seatingPlanId = seatingPlanId;
    }

    public Long getRoomId() {
        return roomId;
    }

    public void setRoomId(Long roomId) {
        this.roomId = roomId;
    }

    public Long getStudentId() {
        return studentId;
    }

    public void setStudentId(Long studentId) {
        this.studentId = studentId;
    }

    public String getRegNo() {
        return regNo;
    }

    public void setRegNo(String regNo) {
        this.regNo = regNo;
    }

    public Integer getSeatRow() {
        return seatRow;
    }

    public void setSeatRow(Integer seatRow) {
        this.seatRow = seatRow;
    }

    public Integer getSeatCol() {
        return seatCol;
    }

    public void setSeatCol(Integer seatCol) {
        this.seatCol = seatCol;
    }
}
