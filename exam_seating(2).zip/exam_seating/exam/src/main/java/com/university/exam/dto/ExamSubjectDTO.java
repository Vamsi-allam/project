package com.university.exam.dto;

import lombok.*;
@Data
@NoArgsConstructor
@Builder
public class ExamSubjectDTO {
    private Long id;
    private Long examId;
    private Long subjectId;
    private Integer setNumber;

    public ExamSubjectDTO(Long id, Long examId, Long subjectId, Integer setNumber) {
        this.id = id;
        this.examId = examId;
        this.subjectId = subjectId;
        this.setNumber = setNumber;
    }
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public Long getExamId() {
        return examId;
    }
    public void setExamId(Long examId) {
        this.examId = examId;
    }
    public Long getSubjectId() {
        return subjectId;
    }
    public void setSubjectId(Long subjectId) {
        this.subjectId = subjectId;
    }
    public Integer getSetNumber() {
        return setNumber;
    }
    public void setSetNumber(Integer setNumber) {
        this.setNumber = setNumber;
    }
    public void setSetNumber(Long setNumber) {
        this.setNumber = setNumber != null ? setNumber.intValue() : null;
    }
}
