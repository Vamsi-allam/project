package com.university.exam.controller;

import com.university.exam.dto.FloorDTO;
import com.university.exam.service.FloorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/floors")
@CrossOrigin(origins = "*")
public class FloorController {

    @Autowired
    private FloorService floorService;

    // Create a new floor
    @PostMapping
    public ResponseEntity<FloorDTO> createFloor(@RequestBody FloorDTO floorDTO) {
        FloorDTO createdFloor = floorService.createFloor(floorDTO);
        return new ResponseEntity<>(createdFloor, HttpStatus.CREATED);
    }

    // Get all floors
    @GetMapping
    public ResponseEntity<List<FloorDTO>> getAllFloors() {
        List<FloorDTO> floors = floorService.getAllFloors();
        return new ResponseEntity<>(floors, HttpStatus.OK);
    }

    // Get floor by ID
    @GetMapping("/{id}")
    public ResponseEntity<FloorDTO> getFloorById(@PathVariable Integer id) {
        FloorDTO floor = floorService.getFloorById(id);
        return new ResponseEntity<>(floor, HttpStatus.OK);
    }

    // Get floors by Block ID
    @GetMapping("/block/{blockId}")
    public ResponseEntity<List<FloorDTO>> getFloorsByBlock(@PathVariable Integer blockId) {
        List<FloorDTO> floors = floorService.getFloorsByBlock(blockId);
        return new ResponseEntity<>(floors, HttpStatus.OK);
    }

    // Update floor by ID
    @PutMapping("/{id}")
    public ResponseEntity<FloorDTO> updateFloor(@PathVariable Integer id, @RequestBody FloorDTO floorDTO) {
        FloorDTO updatedFloor = floorService.updateFloor(id, floorDTO);
        return new ResponseEntity<>(updatedFloor, HttpStatus.OK);
    }

    // Delete floor by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteFloor(@PathVariable Integer id) {
        floorService.deleteFloor(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
