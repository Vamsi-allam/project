package com.university.exam.controller;

import com.university.exam.dto.BlockDTO;
import com.university.exam.service.BlockService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/blocks")
@CrossOrigin(origins = "*")
public class BlockController {

    @Autowired
    private BlockService blockService;

    // Create a new block
    @PostMapping
    public ResponseEntity<BlockDTO> createBlock(@RequestBody BlockDTO blockDTO) {
        BlockDTO createdBlock = blockService.createBlock(blockDTO);
        return new ResponseEntity<>(createdBlock, HttpStatus.CREATED);
    }

    // Get all blocks
    @GetMapping
    public ResponseEntity<List<BlockDTO>> getAllBlocks() {
        List<BlockDTO> blocks = blockService.getAllBlocks();
        return new ResponseEntity<>(blocks, HttpStatus.OK);
    }

    // Get block by ID
    @GetMapping("/{id}")
    public ResponseEntity<BlockDTO> getBlockById(@PathVariable Integer id) {
        BlockDTO block = blockService.getBlockById(id);
        return new ResponseEntity<>(block, HttpStatus.OK);
    }

    // Update block by ID
    @PutMapping("/{id}")
    public ResponseEntity<BlockDTO> updateBlock(@PathVariable Integer id, @RequestBody BlockDTO blockDTO) {
        BlockDTO updatedBlock = blockService.updateBlock(id, blockDTO);
        return new ResponseEntity<>(updatedBlock, HttpStatus.OK);
    }

    // Delete block by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBlock(@PathVariable Integer id) {
        blockService.deleteBlock(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
