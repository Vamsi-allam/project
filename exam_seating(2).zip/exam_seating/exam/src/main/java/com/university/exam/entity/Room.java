package com.university.exam.entity;

import jakarta.persistence.*;
import lombok.Data;
@Entity
@Data
@Table(name = "room")
public class Room {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne
    @JoinColumn(name = "floor_id", nullable = false)
    private Floor floor;
    private String name;
    private Integer rows;
    private Integer cols;

    public Room(String name, Floor floor, Integer rows, Integer cols) {
        this.name = name;
        this.floor = floor;
        this.rows = rows;
        this.cols = cols;
    }
    public Room(String name, Integer rows, Integer cols) {
        this.name = name;
        this.rows = rows;
        this.cols = cols;
    }
    public Room() {
    }
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public Floor getFloor() {
        return floor;
    }
    public void setFloor(Floor floor) {
        this.floor = floor;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public Integer getRows() {
        return rows;
    }
    public void setRows(Integer rows) {
        this.rows = rows;
    }
    public Integer getCols() {
        return cols;
    }
    public void setCols(Integer cols) {
        this.cols = cols;
    }
}