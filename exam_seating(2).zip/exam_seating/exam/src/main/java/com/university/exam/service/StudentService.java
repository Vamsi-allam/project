package com.university.exam.service;

import com.university.exam.dto.StudentDTO;
import com.university.exam.entity.Section;
import com.university.exam.entity.Student;
import com.university.exam.repository.SectionRepository;
import com.university.exam.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private SectionRepository sectionRepository;

    public StudentDTO createStudent(StudentDTO studentDTO) {
        Section section = sectionRepository.findById(studentDTO.getSectionId().intValue())
                .orElseThrow(() -> new IllegalArgumentException("Section not found with id " + studentDTO.getSectionId()));

        Student student = new Student();
        student.setRegNo(studentDTO.getRegNo());
        student.setFullName(studentDTO.getFullName());
        student.setBlocked(studentDTO.getBlocked());
        student.setSection(section);

        return convertToDTO(studentRepository.save(student));
    }

    public StudentDTO getStudentById(Long id) {
        return studentRepository.findById(id)
                .map(this::convertToDTO)
                .orElseThrow(() -> new IllegalArgumentException("Student not found with id " + id));
    }

    public List<StudentDTO> getAllStudents() {
        return studentRepository.findAll()
                .stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public List<StudentDTO> getStudentsBySection(Long sectionId) {
        return studentRepository.findBySectionId(sectionId)
                .stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public StudentDTO getStudentByRegNo(String regNo) {
        return studentRepository.findByRegNo(regNo)
                .map(this::convertToDTO)
                .orElseThrow(() -> new IllegalArgumentException("Student not found with regNo " + regNo));
    }

    public StudentDTO updateStudent(Long id, StudentDTO studentDTO) {
        Student student = studentRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Student not found with id " + id));

        student.setFullName(studentDTO.getFullName());
        student.setBlocked(studentDTO.getBlocked());

        return convertToDTO(studentRepository.save(student));
    }

    public void deleteStudent(Long id) {
        studentRepository.deleteById(id);
    }

    private StudentDTO convertToDTO(Student student) {
        StudentDTO studentDTO = new StudentDTO();
        studentDTO.setId(student.getId());
        studentDTO.setRegNo(student.getRegNo());
        studentDTO.setFullName(student.getFullName());
        studentDTO.setBlocked(student.getBlocked());
        studentDTO.setSectionId(student.getSection().getId());
        return studentDTO;
    }
}
