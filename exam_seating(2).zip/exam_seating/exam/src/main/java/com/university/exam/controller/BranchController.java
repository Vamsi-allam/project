package com.university.exam.controller;

import com.university.exam.dto.BranchDTO;
import com.university.exam.service.BranchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/branches")
@CrossOrigin(origins = "*")
public class BranchController {

    @Autowired
    private BranchService branchService;

    @PostMapping
    public ResponseEntity<BranchDTO> create(@RequestBody BranchDTO dto) {
        return ResponseEntity.ok(branchService.create(dto));
    }

    @GetMapping("/{id}")
    public ResponseEntity<BranchDTO> getById(@PathVariable Integer id) {
        return ResponseEntity.ok(branchService.getById(id));
    }

    @GetMapping
    public ResponseEntity<List<BranchDTO>> listAll() {
        return ResponseEntity.ok(branchService.listAll());
    }

    @GetMapping("/year/{yearId}")
    public ResponseEntity<List<BranchDTO>> getByYear(@PathVariable Integer yearId) {
        return ResponseEntity.ok(branchService.getBranchesByYear(yearId));
    }

    @PutMapping("/{id}")
    public ResponseEntity<BranchDTO> update(@PathVariable Integer id, @RequestBody BranchDTO dto) {
        return ResponseEntity.ok(branchService.update(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Integer id) {
        branchService.delete(id);
        return ResponseEntity.noContent().build();
    }
}