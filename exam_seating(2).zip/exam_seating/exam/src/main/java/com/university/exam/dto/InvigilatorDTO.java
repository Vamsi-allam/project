package com.university.exam.dto;

import lombok.*;
@Data
@Builder
public class InvigilatorDTO {
    private Long id;
    private String fullName;
    private String contactInfo;

    public InvigilatorDTO(String fullName, String contactInfo) {
        this.fullName = fullName;
        this.contactInfo = contactInfo;
    }
    public InvigilatorDTO(Long id, String fullName, String contactInfo) {
        this.id = id;
        this.fullName = fullName;
        this.contactInfo = contactInfo;
    }
    public InvigilatorDTO(){

    }
    public InvigilatorDTO(String fullName) {
        this.fullName = fullName;
    }
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getFullName() {
        return fullName;
    }
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
    public String getContactInfo() {
        return contactInfo;
    }
    public void setContactInfo(String contactInfo) {
        this.contactInfo = contactInfo;
    }
}
