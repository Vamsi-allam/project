package com.university.exam.repository;

import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.university.exam.entity.SeatingPlan;
import java.util.List;
@Repository

public interface SeatingPlanRepository extends JpaRepository<SeatingPlan, Long> {
    List<SeatingPlan> findByExamId(Long examId);
}
