package com.university.exam.entity;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.*;
import lombok.Data;
import java.sql.Timestamp;
@Data
@Entity
@Table(name = "student")
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(unique = true, nullable = false)
    private String regNo;

    private String fullName;
    @ManyToOne
    @JoinColumn(name = "section_id", nullable = false)
    private Section section;
    private Boolean blocked = false;
    @CreationTimestamp
    private Timestamp createdAt;

    public Student(String regNo, String fullName, Section section) {
        this.regNo = regNo;
        this.fullName = fullName;
        this.section = section;
    }
    public Student(String regNo, String fullName) {
        this.regNo = regNo;
        this.fullName = fullName;
    }
    public Student() {
    }
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getRegNo() {
        return regNo;
    }
    public void setRegNo(String regNo) {
        this.regNo = regNo;
    }
    public String getFullName() {
        return fullName;
    }
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
    public Section getSection() {
        return section;
    }
    public void setSection(Section section) {
        this.section = section;
    }
    public Boolean getBlocked() {
        return blocked;
    }
    public void setBlocked(Boolean blocked) {
        this.blocked = blocked;
    }
    public Timestamp getCreatedAt() {
        return createdAt;
    }
    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
    public void setCreatedAt(java.util.Date createdAt) {
        this.createdAt = new Timestamp(createdAt.getTime());
    }
}
