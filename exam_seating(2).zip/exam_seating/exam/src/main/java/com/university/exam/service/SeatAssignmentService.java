package com.university.exam.service;

import com.university.exam.dto.SeatAssignmentDTO;
import com.university.exam.entity.Room;
import com.university.exam.entity.SeatAssignment;
import com.university.exam.entity.SeatingPlan;
import com.university.exam.entity.Student;
import com.university.exam.repository.RoomRepository;
import com.university.exam.repository.SeatAssignmentRepository;
import com.university.exam.repository.SeatingPlanRepository;
import com.university.exam.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class SeatAssignmentService {

    @Autowired
    private SeatAssignmentRepository seatAssignmentRepository;

    @Autowired
    private SeatingPlanRepository seatingPlanRepository;

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private RoomRepository roomRepository;

    public SeatAssignmentDTO createSeatAssignment(SeatAssignmentDTO dto) {
        SeatingPlan plan = seatingPlanRepository.findById(dto.getSeatingPlanId())
                .orElseThrow(() -> new IllegalArgumentException("Invalid Seating Plan ID"));

        Student student = studentRepository.findById(dto.getStudentId())
                .orElseThrow(() -> new IllegalArgumentException("Invalid Student ID"));

        Room room = roomRepository.findById(dto.getRoomId())
                .orElseThrow(() -> new IllegalArgumentException("Invalid Room ID"));

        SeatAssignment sa = new SeatAssignment();
        sa.setSeatingPlan(plan);
        sa.setStudent(student);
        sa.setRoom(room);
        sa.setSeatRow(dto.getSeatRow());
        sa.setSeatCol(dto.getSeatCol());

        return toDTO(seatAssignmentRepository.save(sa));
    }

    public SeatAssignmentDTO getSeatAssignment(Long id) {
        return seatAssignmentRepository.findById(id)
                .map(this::toDTO)
                .orElseThrow(() -> new IllegalArgumentException("SeatAssignment not found with id " + id));
    }

    public List<SeatAssignmentDTO> getAssignmentsByPlan(Long planId) {
        return seatAssignmentRepository.findBySeatingPlanId(planId).stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    public void deleteSeatAssignment(Long id) {
        seatAssignmentRepository.deleteById(id);
    }

    private SeatAssignmentDTO toDTO(SeatAssignment sa) {
        SeatAssignmentDTO dto = new SeatAssignmentDTO();
        dto.setSeatingPlanId(sa.getSeatingPlan().getId());
        dto.setStudentId(sa.getStudent().getId());
        dto.setRoomId(sa.getRoom().getId());
        dto.setSeatRow(sa.getSeatRow());
        dto.setSeatCol(sa.getSeatCol());
        return dto;
    }
}
