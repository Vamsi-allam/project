package com.university.exam.dto;

import lombok.*;
import java.util.List;
@Data
public class CreatePlanRequest {
    private Long ExamId;
    private Long blockId;
    private List<Long> sectionIds;
    public CreatePlanRequest(Long examId, Long blockId, List<Long> sectionIds) {
        ExamId = examId;
        this.blockId = blockId;
        this.sectionIds = sectionIds;
    }
    public CreatePlanRequest() {
    }
    public Long getExamId() {
        return ExamId;
    }
    public void setExamId(Long examId) {
        ExamId = examId;
    }
    public Long getBlockId() {
        return blockId;
    }
    public void setBlockId(Long blockId) {
        this.blockId = blockId;
    }
    public List<Long> getSectionIds() {
        return sectionIds;
    }
    public void setSectionIds(List<Long> sectionIds) {
        this.sectionIds = sectionIds;
    }
}
