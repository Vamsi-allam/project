package com.university.exam.dto;

import lombok.*;
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FloorDTO {
    private Integer id;
    private Integer blockId;
    private Integer level;

    public FloorDTO(Integer blockId, Integer level) {
        this.blockId = blockId;
        this.level = level;
    }
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public Integer getBlockId() {
        return blockId;
    }
    public void setBlockId(Integer blockId) {
        this.blockId = blockId;
    }
    public Integer getLevel() {
        return level;
    }
    public void setLevel(Integer level) {
        this.level = level;
    }

}
