package com.university.exam.service;

import com.university.exam.dto.ExamSubjectDTO;
import com.university.exam.entity.Exam;
import com.university.exam.entity.ExamSubject;
import com.university.exam.entity.Subject;
import com.university.exam.repository.ExamRepository;
import com.university.exam.repository.ExamSubjectRepository;
import com.university.exam.repository.SubjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ExamSubjectService {

    @Autowired
    private ExamSubjectRepository examSubjectRepository;

    @Autowired
    private ExamRepository examRepository;

    @Autowired
    private SubjectRepository subjectRepository;

    public ExamSubjectDTO createExamSubject(ExamSubjectDTO dto) {
        Exam exam = examRepository.findById(dto.getExamId())
            .orElseThrow(() -> new IllegalArgumentException("Exam not found with id " + dto.getExamId()));

        Subject subject = subjectRepository.findById(dto.getSubjectId())
            .orElseThrow(() -> new IllegalArgumentException("Subject not found with id " + dto.getSubjectId()));

        ExamSubject entity = new ExamSubject();
        entity.setExam(exam);
        entity.setSubject(subject);
        entity.setSetNumber(dto.getSetNumber());

        ExamSubject saved = examSubjectRepository.save(entity);
        return toDTO(saved);
    }

    public ExamSubjectDTO getExamSubjectById(Long id) {
        ExamSubject es = examSubjectRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("ExamSubject not found with id " + id));
        return toDTO(es);
    }

    public List<ExamSubjectDTO> getAllExamSubjects() {
        return examSubjectRepository.findAll().stream()
            .map(this::toDTO)
            .collect(Collectors.toList());
    }

    public List<ExamSubjectDTO> getByExamId(Long examId) {
        return examSubjectRepository.findByExamId(examId).stream()
            .map(this::toDTO)
            .collect(Collectors.toList());
    }

    public ExamSubjectDTO updateExamSubject(Long id, ExamSubjectDTO dto) {
        ExamSubject es = examSubjectRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("ExamSubject not found with id " + id));

        es.setSetNumber(dto.getSetNumber());

        // Optional: allow updating examId or subjectId if needed
        if (dto.getExamId() != null && !dto.getExamId().equals(es.getExam().getId())) {
            Exam exam = examRepository.findById(dto.getExamId())
                .orElseThrow(() -> new IllegalArgumentException("Exam not found with id " + dto.getExamId()));
            es.setExam(exam);
        }

        if (dto.getSubjectId() != null && !dto.getSubjectId().equals(es.getSubject().getId())) {
            Subject subject = subjectRepository.findById(dto.getSubjectId())
                .orElseThrow(() -> new IllegalArgumentException("Subject not found with id " + dto.getSubjectId()));
            es.setSubject(subject);
        }

        ExamSubject updated = examSubjectRepository.save(es);
        return toDTO(updated);
    }

    public void deleteExamSubject(Long id) {
        examSubjectRepository.deleteById(id);
    }

    private ExamSubjectDTO toDTO(ExamSubject es) {
        return new ExamSubjectDTO(
            es.getId(),
            es.getExam().getId(),
            es.getSubject().getId(),
            es.getSetNumber()
        );
    }
}
