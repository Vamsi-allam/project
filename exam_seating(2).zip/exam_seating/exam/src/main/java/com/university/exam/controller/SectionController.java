package com.university.exam.controller;

import com.university.exam.dto.SectionDTO;
import com.university.exam.service.SectionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/sections")
@CrossOrigin(origins = "*")
public class SectionController {

    @Autowired
    private SectionService sectionService;

    @PostMapping
    public ResponseEntity<SectionDTO> create(@RequestBody SectionDTO dto) {
        return ResponseEntity.ok(sectionService.create(dto));
    }

    @GetMapping("/{id}")
    public ResponseEntity<SectionDTO> getById(@PathVariable Integer id) {
        return ResponseEntity.ok(sectionService.getById(id));
    }

    @GetMapping
    public ResponseEntity<List<SectionDTO>> listAll() {
        return ResponseEntity.ok(sectionService.listAll());
    }

    @GetMapping("/by-branch/{branchId}")
    public ResponseEntity<List<SectionDTO>> getByBranch(@PathVariable Integer branchId) {
        return ResponseEntity.ok(sectionService.getSectionsByBranch(branchId));
    }

    @PutMapping("/{id}")
    public ResponseEntity<SectionDTO> update(@PathVariable Integer id, @RequestBody SectionDTO dto) {
        return ResponseEntity.ok(sectionService.update(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Integer id) {
        sectionService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
