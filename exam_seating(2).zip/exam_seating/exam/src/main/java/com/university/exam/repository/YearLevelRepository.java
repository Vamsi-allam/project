package com.university.exam.repository;

import com.university.exam.entity.YearLevel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface YearLevelRepository extends JpaRepository<YearLevel, Integer> {
    // Changed from findByYearLevelId to findById since id is the property name in YearLevel entity
    YearLevel findById(int id);
}
