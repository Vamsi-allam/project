package com.university.exam.controller;

import com.university.exam.dto.InvigilatorDTO;
import com.university.exam.service.InvigilatorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/invigilators")
@CrossOrigin(origins = "*")
public class InvigilatorController {

    @Autowired
    private InvigilatorService invigilatorService;

    @PostMapping
    public ResponseEntity<InvigilatorDTO> create(@RequestBody InvigilatorDTO dto) {
        return ResponseEntity.ok(invigilatorService.createInvigilator(dto));
    }

    @GetMapping
    public ResponseEntity<List<InvigilatorDTO>> getAll() {
        return ResponseEntity.ok(invigilatorService.getAllInvigilators());
    }

    @GetMapping("/{id}")
    public ResponseEntity<InvigilatorDTO> getById(@PathVariable Long id) {
        return ResponseEntity.ok(invigilatorService.getInvigilatorById(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<InvigilatorDTO> update(@PathVariable Long id, @RequestBody InvigilatorDTO dto) {
        return ResponseEntity.ok(invigilatorService.updateInvigilator(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        invigilatorService.deleteInvigilator(id);
        return ResponseEntity.noContent().build();
    }
}
