package com.university.exam.controller;

import com.university.exam.dto.YearLevelDTO;
import com.university.exam.service.YearLevelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import java.util.List;
@RestController
@RequestMapping("/api/year-levels")
@CrossOrigin(origins = "*")
public class YearLevelController {
    @Autowired
    private YearLevelService yearLevelService;
    @PostMapping
    public ResponseEntity<YearLevelDTO> create(@RequestBody YearLevelDTO dto) {
        return new ResponseEntity<>(yearLevelService.create(dto), HttpStatus.CREATED);
    }
    @GetMapping("/{id}")
    public ResponseEntity<YearLevelDTO> getById(@PathVariable Integer id) {
        return ResponseEntity.ok(yearLevelService.getById(id));
    }
    @GetMapping
    public ResponseEntity<List<YearLevelDTO>> listAll() {
        return ResponseEntity.ok(yearLevelService.listAll());
    }
    @PutMapping("/{id}")
    public ResponseEntity<YearLevelDTO> update(@PathVariable Integer id, @RequestBody YearLevelDTO dto) {
        return ResponseEntity.ok(yearLevelService.update(id, dto));
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Integer id) {
        yearLevelService.delete(id);
        return ResponseEntity.noContent().build();
    }
}