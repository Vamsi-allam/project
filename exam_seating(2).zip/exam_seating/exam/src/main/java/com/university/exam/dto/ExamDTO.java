package com.university.exam.dto;

import lombok.*;
import java.sql.Date;
import java.sql.Time;
@Data
@NoArgsConstructor
@Builder
public class ExamDTO {
    private Long id;
    private String name;
    private Date examDate;
    private Time startTime;
    private Time endTime;

    public ExamDTO(String name, Date examDate, Time startTime, Time endTime) {
        this.name = name;
        this.examDate = examDate;
        this.startTime = startTime;
        this.endTime = endTime;
    }
    public ExamDTO(String name, Date examDate) {
        this.name = name;
        this.examDate = examDate;
    }
    public ExamDTO(Long id, String name, Date examDate, Time startTime, Time endTime) {
        this.id = id;
        this.name = name;
        this.examDate = examDate;
        this.startTime = startTime;
        this.endTime = endTime;
    }
    public ExamDTO(String name) {
        this.name = name;
    }
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public Date getExamDate() {
        return examDate;
    }
    public void setExamDate(Date examDate) {
        this.examDate = examDate;
    }
    public Time getStartTime() {
        return startTime;
    }
    public void setStartTime(Time startTime) {
        this.startTime = startTime;
    }
    public Time getEndTime() {
        return endTime;
    }
    public void setEndTime(Time endTime) {
        this.endTime = endTime;
    }
}
