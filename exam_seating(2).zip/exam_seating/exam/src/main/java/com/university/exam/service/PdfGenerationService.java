package com.university.exam.service;

import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.properties.TextAlignment;
import com.itextpdf.layout.properties.UnitValue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.university.exam.dto.SeatAssignmentDTO;
import com.university.exam.service.StudentService;  // Assuming StudentService is available

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

@Service
public class PdfGenerationService {

    @Autowired
    private StudentService studentService;  // Assuming StudentService exists

    public byte[] generateSeatingPlanPdf(List<SeatAssignmentDTO> seatAssignments) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PdfWriter writer = new PdfWriter(baos);
        PdfDocument pdf = new PdfDocument(writer);
        Document document = new Document(pdf);

        // Add title
        Paragraph title = new Paragraph("Seating Arrangement")
            .setTextAlignment(TextAlignment.CENTER)
            .setFontSize(20)
            .setBold();
        document.add(title);

        document.add(new Paragraph("Seating plan for the upcoming exam."));

        // Create table
        Table table = new Table(UnitValue.createPercentArray(new float[]{25, 25, 25, 25}));
        table.setWidth(UnitValue.createPercentValue(100));

        // Add headers
        table.addHeaderCell(new Cell().add(new Paragraph("Student Reg No")));
        table.addHeaderCell(new Cell().add(new Paragraph("Room")));
        table.addHeaderCell(new Cell().add(new Paragraph("Seat Row")));
        table.addHeaderCell(new Cell().add(new Paragraph("Seat Column")));

        // Add data
        for (SeatAssignmentDTO assignment : seatAssignments) {
            // Use regNo from the SeatAssignmentDTO directly
            String regNo = assignment.getRegNo();

            // Add cells to the table
            table.addCell(new Cell().add(new Paragraph(regNo)));
            table.addCell(new Cell().add(new Paragraph(String.valueOf(assignment.getRoomId()))));
            table.addCell(new Cell().add(new Paragraph(String.valueOf(assignment.getSeatRow()))));
            table.addCell(new Cell().add(new Paragraph(String.valueOf(assignment.getSeatCol()))));
        }

        document.add(table);
        document.close();

        return baos.toByteArray();
    }
}
