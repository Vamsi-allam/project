package com.university.exam.repository;

import com.university.exam.entity.PlanRoomInvigilator;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.university.exam.entity.PlanRoomInvigilatorId;

import java.util.List;
@Repository
public interface PlanRoomInvigilatorRepository extends JpaRepository<PlanRoomInvigilator,PlanRoomInvigilatorId> {
    List<PlanRoomInvigilator> findBySeatingPlanId(Long seatingPlanId);
    void deleteBySeatingPlanId(Long seatingPlanId);
}