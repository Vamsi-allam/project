package com.university.exam.service;

import com.university.exam.entity.Exam;
import com.university.exam.repository.ExamRepository;
import com.university.exam.dto.ExamDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ExamService {

    @Autowired
    private ExamRepository examRepository;

    // Create Exam
    public ExamDTO createExam(ExamDTO examDTO) {
        Exam exam = new Exam();
        exam.setName(examDTO.getName());
        exam.setExamDate(examDTO.getExamDate());
        exam.setStartTime(examDTO.getStartTime());
        exam.setEndTime(examDTO.getEndTime());

        exam = examRepository.save(exam);
        return toDTO(exam);
    }

    // Get Exam by ID
    public ExamDTO getExamById(Long id) {
        Exam exam = examRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Exam not found with id " + id));
        return toDTO(exam);
    }

    // Get All Exams
    public List<ExamDTO> getAllExams() {
        List<Exam> exams = examRepository.findAll();
        return exams.stream().map(this::toDTO).collect(Collectors.toList());
    }

    // Get Exams by Date
    public List<ExamDTO> getExamsByDate(java.util.Date date) {
        List<Exam> exams = examRepository.findByExamDate(new java.sql.Date(date.getTime()));
        return exams.stream().map(this::toDTO).collect(Collectors.toList());
    }

    // Update Exam by ID
    public ExamDTO updateExam(Long id, ExamDTO examDTO) {
        Exam exam = examRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Exam not found with id " + id));

        exam.setName(examDTO.getName());
        exam.setExamDate(examDTO.getExamDate());
        exam.setStartTime(examDTO.getStartTime());
        exam.setEndTime(examDTO.getEndTime());

        exam = examRepository.save(exam);
        return toDTO(exam);
    }

    // Delete Exam by ID
    public void deleteExam(Long id) {
        examRepository.deleteById(id);
    }

    // Helper method to convert Exam entity to ExamDTO
    private ExamDTO toDTO(Exam exam) {
        return new ExamDTO(
            exam.getId(),
            exam.getName(),
            new java.sql.Date(exam.getExamDate().getTime()), // Converting java.util.Date to java.sql.Date
            exam.getStartTime(),
            exam.getEndTime()
        );
    }
}
