package com.university.exam.dto;

import lombok.*;
@AllArgsConstructor
@Builder
public class SectionDTO {
    private Integer id;
    private String name;
    private Integer branchId;
    public SectionDTO(){
        
    }
    public SectionDTO(String name, Integer branchId) {
        this.name = name;
        this.branchId = branchId;
    }
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public Integer getBranchId() {
        return branchId;
    }
    public void setBranchId(Integer branchId) {
        this.branchId = branchId;
    }
    
}
