package com.university.exam.entity;

import jakarta.persistence.*;
import lombok.Data;
@Entity
@Data
@Table(name = "seat_assignment")
public class SeatAssignment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne
    @JoinColumn(name = "seating_plan_id", nullable = false)
    private SeatingPlan seatingPlan;
    @ManyToOne
    @JoinColumn(name = "student_id", nullable = false)
    private Student student;
    @ManyToOne
    @JoinColumn(name = "room_id", nullable = false)
    private Room room;
    private Integer seatRow;
    private Integer seatCol;

    public SeatAssignment(SeatingPlan seatingPlan, Student student, Room room, Integer seatRow, Integer seatCol) {
        this.seatingPlan = seatingPlan;
        this.student = student;
        this.room = room;
        this.seatRow = seatRow;
        this.seatCol = seatCol;
    }
    public SeatAssignment() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public SeatingPlan getSeatingPlan() {
        return seatingPlan;
    }

    public void setSeatingPlan(SeatingPlan seatingPlan) {
        this.seatingPlan = seatingPlan;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public Room getRoom() {
        return room;
    }

    public void setRoom(Room room) {
        this.room = room;
    }

    public Integer getSeatRow() {
        return seatRow;
    }

    public void setSeatRow(Integer seatRow) {
        this.seatRow = seatRow;
    }

    public Integer getSeatCol() {
        return seatCol;
    }

    public void setSeatCol(Integer seatCol) {
        this.seatCol = seatCol;
    }
}
