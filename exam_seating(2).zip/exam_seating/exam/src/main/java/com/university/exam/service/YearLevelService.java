package com.university.exam.service;

import com.university.exam.dto.YearLevelDTO;
import com.university.exam.entity.YearLevel;
import com.university.exam.repository.YearLevelRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class YearLevelService {

    @Autowired
    private YearLevelRepository yearLevelRepository;

    public YearLevelDTO create(YearLevelDTO dto) {
        YearLevel yearLevel = new YearLevel();
        yearLevel.setName(dto.getName());
        yearLevel.setNote(dto.getNote());
        return convertToDTO(yearLevelRepository.save(yearLevel));
    }

    public YearLevelDTO getById(Integer id) {
        YearLevel yearLevel = yearLevelRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("YearLevel not found with id " + id));
        return convertToDTO(yearLevel);
    }

    public List<YearLevelDTO> listAll() {
        return yearLevelRepository.findAll()
                .stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public YearLevelDTO update(Integer id, YearLevelDTO dto) {
        YearLevel yearLevel = yearLevelRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("YearLevel not found with id " + id));
        yearLevel.setName(dto.getName());
        yearLevel.setNote(dto.getNote());
        return convertToDTO(yearLevelRepository.save(yearLevel));
    }

    public void delete(Integer id) {
        yearLevelRepository.deleteById(id);
    }

    private YearLevelDTO convertToDTO(YearLevel yearLevel) {
        YearLevelDTO dto = new YearLevelDTO();
        dto.setId(yearLevel.getId());
        dto.setName(yearLevel.getName());
        dto.setNote(yearLevel.getNote());
        return dto;
    }
}
