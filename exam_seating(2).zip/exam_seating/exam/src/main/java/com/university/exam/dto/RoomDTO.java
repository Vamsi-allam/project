package com.university.exam.dto;

import lombok.*;
@Data
@NoArgsConstructor
public class RoomDTO {
    private Long id;
    private String name;
    private Integer rows;
    private Integer cols;
    private Integer floorId;

    public RoomDTO(String name, Integer rows, Integer cols) {
        this.name = name;
        this.rows = rows;
        this.cols = cols;
    }
    public RoomDTO(String name, Integer rows, Integer cols, Integer floorId) {
        this.name = name;
        this.rows = rows;
        this.cols = cols;
        this.floorId = floorId;
    }
    public RoomDTO(Long id, String name, Integer rows, Integer cols, Integer floorId) {
        this.id = id;
        this.name = name;
        this.rows = rows;
        this.cols = cols;
        this.floorId = floorId;
    }
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public Integer getRows() {
        return rows;
    }
    public void setRows(Integer rows) {
        this.rows = rows;
    }
    public Integer getCols() {
        return cols;
    }
    public void setCols(Integer cols) {
        this.cols = cols;
    }
    public Integer getFloorId() {
        return floorId;
    }
    public void setFloorId(Integer floorId) {
        this.floorId = floorId;
    }
}
