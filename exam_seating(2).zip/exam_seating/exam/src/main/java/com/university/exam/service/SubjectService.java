package com.university.exam.service;

import com.university.exam.dto.SubjectDTO;
import com.university.exam.entity.Subject;
import com.university.exam.repository.SubjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class SubjectService {

    @Autowired
    private SubjectRepository subjectRepository;

    public SubjectDTO createSubject(SubjectDTO dto) {
        Subject subject = new Subject();
        subject.setCode(dto.getCode());
        subject.setTitle(dto.getTitle());

        Subject saved = subjectRepository.save(subject);
        return toDTO(saved);
    }

    public SubjectDTO getSubjectById(Long id) {
        Subject subject = subjectRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Subject not found with id " + id));
        return toDTO(subject);
    }

    public List<SubjectDTO> getAllSubjects() {
        return subjectRepository.findAll().stream()
            .map(this::toDTO)
            .collect(Collectors.toList());
    }

    public SubjectDTO updateSubject(Long id, SubjectDTO dto) {
        Subject subject = subjectRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Subject not found with id " + id));

        subject.setCode(dto.getCode());
        subject.setTitle(dto.getTitle());

        Subject updated = subjectRepository.save(subject);
        return toDTO(updated);
    }

    public void deleteSubject(Long id) {
        subjectRepository.deleteById(id);
    }

    private SubjectDTO toDTO(Subject subject) {
        SubjectDTO dto = new SubjectDTO();
        dto.setId(subject.getId());
        dto.setCode(subject.getCode());
        dto.setTitle(subject.getTitle());
        return dto;
    }
}
