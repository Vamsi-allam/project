package com.university.exam.controller;

import com.university.exam.dto.ExamDTO;
import com.university.exam.service.ExamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/exams")
@CrossOrigin(origins = "*")
public class ExamController {

    @Autowired
    private ExamService examService;

    // Create a new exam
    @PostMapping
    public ResponseEntity<ExamDTO> createExam(@RequestBody ExamDTO examDTO) {
        ExamDTO createdExam = examService.createExam(examDTO);
        return new ResponseEntity<>(createdExam, HttpStatus.CREATED);
    }

    // Get all exams
    @GetMapping
    public ResponseEntity<List<ExamDTO>> getAllExams() {
        List<ExamDTO> exams = examService.getAllExams();
        return new ResponseEntity<>(exams, HttpStatus.OK);
    }

    // Get exam by ID
    @GetMapping("/{id}")
    public ResponseEntity<ExamDTO> getExamById(@PathVariable Long id) {
        ExamDTO exam = examService.getExamById(id);
        return new ResponseEntity<>(exam, HttpStatus.OK);
    }

    // Get exams by date
    @GetMapping("/date/{date}")
    public ResponseEntity<List<ExamDTO>> getExamsByDate(@PathVariable java.util.Date date) {
        List<ExamDTO> exams = examService.getExamsByDate(date);
        return new ResponseEntity<>(exams, HttpStatus.OK);
    }

    // Update exam by ID
    @PutMapping("/{id}")
    public ResponseEntity<ExamDTO> updateExam(@PathVariable Long id, @RequestBody ExamDTO examDTO) {
        ExamDTO updatedExam = examService.updateExam(id, examDTO);
        return new ResponseEntity<>(updatedExam, HttpStatus.OK);
    }

    // Delete exam by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteExam(@PathVariable Long id) {
        examService.deleteExam(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
