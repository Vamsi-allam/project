package com.university.exam.entity;

import jakarta.persistence.Embeddable;

import java.io.Serializable;

import java.util.Objects;

@Embeddable
public class PlanRoomInvigilatorId implements Serializable {

    private Long seatingPlanId;

    private Long roomId;

    public PlanRoomInvigilatorId() {
    }

    public PlanRoomInvigilatorId(Long seatingPlanId, Long roomId) {
        this.seatingPlanId = seatingPlanId;
        this.roomId = roomId;
    }

    public Long getSeatingPlanId() {
        return seatingPlanId;
    }

    public void setSeatingPlanId(Long seatingPlanId) {
        this.seatingPlanId = seatingPlanId;
    }

    public Long getRoomId() {
        return roomId;
    }

    public void setRoomId(Long roomId) {
        this.roomId = roomId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PlanRoomInvigilatorId that = (PlanRoomInvigilatorId) o;
        return Objects.equals(seatingPlanId, that.seatingPlanId) &&
               Objects.equals(roomId, that.roomId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(seatingPlanId, roomId);
    }
}