package com.university.exam.controller;

import com.university.exam.dto.*;
import com.university.exam.service.PdfGenerationService;
import com.university.exam.service.SeatingPlanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api/seating-plans")
@CrossOrigin(origins = "*")
public class SeatingPlanController {

    @Autowired
    private SeatingPlanService seatingPlanService;

    @Autowired
    private PdfGenerationService pdfGenerationService;

    @PostMapping("/create")
    public ResponseEntity<SeatingPlanDTO> createPlan(@RequestBody CreatePlanRequest request) {
        return ResponseEntity.ok(seatingPlanService.createPlan(request));
    }

    @PostMapping("/{planId}/update-rooms")
    public ResponseEntity<SeatingPlanDTO> updateRooms(@PathVariable Long planId, @RequestBody RoomAdjustmentRequest request) {
        return ResponseEntity.ok(seatingPlanService.updateRooms(planId, request));
    }

    @PostMapping("/{planId}/finalize")
    public ResponseEntity<SeatingPlanDTO> finalizePlan(@PathVariable Long planId, @RequestBody List<InvigilatorAssignment> assignments) {
        return ResponseEntity.ok(seatingPlanService.finalizePlan(planId, assignments));
    }

    @GetMapping("/{planId}")
    public ResponseEntity<SeatingPlanDTO> getPlan(@PathVariable Long planId) {
        return ResponseEntity.ok(seatingPlanService.getPlan(planId));
    }

    @PostMapping("/{planId}/regenerate")
    public ResponseEntity<SeatingPlanDTO> regenerate(@PathVariable Long planId) {
        return ResponseEntity.ok(seatingPlanService.regeneratePlan(planId));
    }

    @DeleteMapping("/{planId}")
    public ResponseEntity<Void> delete(@PathVariable Long planId) {
        seatingPlanService.deletePlan(planId);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/{planId}/download")
    public ResponseEntity<byte[]> downloadSeatingPlanPdf(@PathVariable Long planId) throws IOException {
        List<SeatAssignmentDTO> seatAssignments = seatingPlanService.getSeatAssignmentsByPlanId(planId);
        
        byte[] pdfContent = pdfGenerationService.generateSeatingPlanPdf(seatAssignments);
        
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_PDF);
        headers.add("Content-Disposition", "attachment; filename=seating-plan.pdf");
        
        return ResponseEntity
            .ok()
            .headers(headers)
            .body(pdfContent);
    }
}
