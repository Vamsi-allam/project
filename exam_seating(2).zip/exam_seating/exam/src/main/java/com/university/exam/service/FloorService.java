package com.university.exam.service;

import com.university.exam.entity.Floor;
import com.university.exam.repository.FloorRepository;
import com.university.exam.dto.FloorDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.university.exam.entity.Block;
import com.university.exam.repository.BlockRepository;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class FloorService {

    @Autowired
    private FloorRepository floorRepository;

    @Autowired
    private BlockRepository blockRepository;

    // Create Floor
    public FloorDTO createFloor(FloorDTO floorDTO) {
        Floor floor = new Floor();
        floor.setLevel(floorDTO.getLevel());

        // Assuming the block is already present and valid, we fetch it using the blockId
        Block block = blockRepository.findById(floorDTO.getBlockId())
            .orElseThrow(() -> new IllegalArgumentException("Block not found with id " + floorDTO.getBlockId()));

        floor.setBlock(block);

        floor = floorRepository.save(floor);
        return toDTO(floor);
    }

    // Get Floor by ID
    public FloorDTO getFloorById(Integer id) {
        Floor floor = floorRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Floor not found with id " + id));
        return toDTO(floor);
    }

    // Get All Floors
    public List<FloorDTO> getAllFloors() {
        List<Floor> floors = floorRepository.findAll();
        return floors.stream().map(this::toDTO).collect(Collectors.toList());
    }

    // Get Floors by Block ID
    public List<FloorDTO> getFloorsByBlock(Integer blockId) {
        List<Floor> floors = floorRepository.findByBlockId(blockId);
        return floors.stream().map(this::toDTO).collect(Collectors.toList());
    }

    // Update Floor by ID
    public FloorDTO updateFloor(Integer id, FloorDTO floorDTO) {
        Floor floor = floorRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Floor not found with id " + id));

        floor.setLevel(floorDTO.getLevel());

        // Assuming the blockId is being updated as well
        Block block = blockRepository.findById(floorDTO.getBlockId())
            .orElseThrow(() -> new IllegalArgumentException("Block not found with id " + floorDTO.getBlockId()));

        floor.setBlock(block);

        floor = floorRepository.save(floor);
        return toDTO(floor);
    }

    // Delete Floor by ID
    public void deleteFloor(Integer id) {
        floorRepository.deleteById(id);
    }

    // Helper method to convert Floor entity to FloorDTO
    private FloorDTO toDTO(Floor floor) {
        return new FloorDTO(
            floor.getId(),
            floor.getBlock().getId()
        );
    }
}
