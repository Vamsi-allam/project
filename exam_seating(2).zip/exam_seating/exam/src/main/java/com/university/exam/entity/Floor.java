package com.university.exam.entity;

import jakarta.persistence.*;
import lombok.Data;
@Entity
@Data
@Table(name = "floor")
public class Floor {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @ManyToOne
    @JoinColumn(name = "block_id", nullable = false)
    private Block block;
    private Integer level;

    public Floor(Integer level, Block block) {
        this.level = level;
        this.block = block;
    }
    public Floor(Integer level) {
        this.level = level;
    }
    public Floor() {
    }
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public Block getBlock() {
        return block;
    }
    public void setBlock(Block block) {
        this.block = block;
    }
    public Integer getLevel() {
        return level;
    }
    public void setLevel(Integer level) {
        this.level = level;
    }
}