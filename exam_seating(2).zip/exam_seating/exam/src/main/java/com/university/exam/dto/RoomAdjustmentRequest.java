package com.university.exam.dto;

import lombok.*;
import java.util.List;
@Data
public class RoomAdjustmentRequest {
    private List<Long> roomIds;
    public RoomAdjustmentRequest() {
    }
    public RoomAdjustmentRequest(List<Long> roomIds) {
        this.roomIds = roomIds;
    }
    public List<Long> getRoomIds() {
        return roomIds;
    }
    public void setRoomIds(List<Long> roomIds) {
        this.roomIds = roomIds;
    }
    
}
