package com.university.exam.dto;

import lombok.*;
@Data
@AllArgsConstructor
@Builder
public class StudentDTO {
    private Long id;
    private String regNo;
    private String fullName;
    private Boolean blocked;
    private Long sectionId;

    public StudentDTO(Long id, String regNo, String fullName, Boolean blocked, Integer sectionId) {
        this.id = id;
        this.regNo = regNo;
        this.fullName = fullName;
        this.blocked = blocked;
        this.sectionId = sectionId != null ? Long.valueOf(sectionId) : null;
    }
    public StudentDTO(){

    }
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getRegNo() {
        return regNo;
    }
    public void setRegNo(String regNo) {
        this.regNo = regNo;
    }
    public String getFullName() {
        return fullName;
    }
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
    public Boolean getBlocked() {
        return blocked;
    }
    public void setBlocked(Boolean blocked) {
        this.blocked = blocked;
    }
    public Long getSectionId() {
        return sectionId;
    }
    public void setSectionId(Long sectionId) {
        this.sectionId = sectionId;
    }
    public void setSectionId(Integer sectionId) {
        this.sectionId = sectionId != null ? Long.valueOf(sectionId) : null;
    }
}
