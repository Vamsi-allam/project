package com.university.exam.service;
import java.util.*;

import com.university.exam.entity.*;
import com.university.exam.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
@Service
@Transactional(readOnly = true)
public class RoomAllocationService {
    @Autowired private RoomRepository roomRepo;
    public List<Room> allocateRooms(Integer blockId, Map<Long,Integer> studentCounts) {
        int total = studentCounts.values().stream().mapToInt(i -> i).sum();
        List<Room> all = roomRepo.findByBlockId(blockId);
        all.sort(Comparator.comparingInt(r -> -r.getRows() * r.getCols()));
        List<Room> picked = new ArrayList<>();
        int sum = 0;
        for (Room r : all) {
            if (sum >= total) break;
            picked.add(r);
            sum += r.getRows() * r.getCols();
        }
        return picked;
    }
    public List<SeatAssignment> assignSeats(SeatingPlan plan, List<Student> students) {
        List<SeatAssignment> out = new ArrayList<>();
        Iterator<Student> it = students.iterator();
        for (Room room : plan.getRooms()) {
            for (int r = 1; r <= room.getRows() && it.hasNext(); r++) {
                for (int c = 1; c <= room.getCols() && it.hasNext(); c++) {
                    Student s = it.next();
                    SeatAssignment sa = new SeatAssignment();
                    sa.setSeatingPlan(plan);
                    sa.setRoom(room);
                    sa.setStudent(s);
                    sa.setSeatRow(r);
                    sa.setSeatCol(c);
                    out.add(sa);
                }
            }
            if (!it.hasNext()) break;
        }
        return out;
    }
}