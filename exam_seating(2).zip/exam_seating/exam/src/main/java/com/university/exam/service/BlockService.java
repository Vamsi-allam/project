package com.university.exam.service;

import com.university.exam.entity.Block;
import com.university.exam.repository.BlockRepository;
import com.university.exam.dto.BlockDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class BlockService {

    @Autowired
    private BlockRepository blockRepository;

    // Create Block
    public BlockDTO createBlock(BlockDTO blockDTO) {
        Block block = new Block();
        block.setName(blockDTO.getName());

        block = blockRepository.save(block);
        return toDTO(block);
    }

    // Get Block by ID
    public BlockDTO getBlockById(Integer id) {
        Block block = blockRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Block not found with id " + id));
        return toDTO(block);
    }

    // Get All Blocks
    public List<BlockDTO> getAllBlocks() {
        List<Block> blocks = blockRepository.findAll();
        return blocks.stream().map(this::toDTO).collect(Collectors.toList());
    }

    // Update Block by ID
    public BlockDTO updateBlock(Integer id, BlockDTO blockDTO) {
        Block block = blockRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Block not found with id " + id));

        block.setName(blockDTO.getName());

        block = blockRepository.save(block);
        return toDTO(block);
    }

    // Delete Block by ID
    public void deleteBlock(Integer id) {
        blockRepository.deleteById(id);
    }

    // Helper method to convert Block entity to BlockDTO
    private BlockDTO toDTO(Block block) {
        return new BlockDTO(
            block.getName()
        );
    }
}
