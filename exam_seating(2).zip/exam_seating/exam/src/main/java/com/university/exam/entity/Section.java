package com.university.exam.entity;

import jakarta.persistence.*;
import lombok.Data;
@Data
@Entity
@Table(name = "section")
public class Section {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @ManyToOne
    @JoinColumn(name = "branch_id", nullable = false)
    private Branch branch;
    private String name;

    public Section(String name, Branch branch) {
        this.name = name;
        this.branch = branch;
    }
    public Section(String name) {
        this.name = name;
    }
    public Section() {
    }
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public Branch getBranch() {
        return branch;
    }
    public void setBranch(Branch branch) {
        this.branch = branch;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
}