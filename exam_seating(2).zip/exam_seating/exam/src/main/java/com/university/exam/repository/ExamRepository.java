package com.university.exam.repository;

import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.university.exam.entity.Exam;
import java.util.List;
import java.util.Date;

@Repository
public interface ExamRepository extends JpaRepository<Exam, Long> {
    List<Exam> findByExamDate(Date examDate);
}