package com.university.exam.service;

import com.university.exam.dto.SectionDTO;
import com.university.exam.entity.Branch;
import com.university.exam.entity.Section;
import com.university.exam.repository.BranchRepository;
import com.university.exam.repository.SectionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class SectionService {

    @Autowired
    private SectionRepository sectionRepository;

    @Autowired
    private BranchRepository branchRepository;

    public SectionDTO create(SectionDTO dto) {
        Branch branch = branchRepository.findById(dto.getBranchId())
                .orElseThrow(() -> new IllegalArgumentException("Branch not found"));
        Section section = new Section();
        section.setName(dto.getName());
        section.setBranch(branch);
        section = sectionRepository.save(section);
        return mapToDTO(section);
    }

    public SectionDTO getById(Integer id) {
        return sectionRepository.findById(id)
                .map(this::mapToDTO)
                .orElseThrow(() -> new IllegalArgumentException("Section not found with id " + id));
    }

    public List<SectionDTO> listAll() {
        return sectionRepository.findAll().stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    public List<SectionDTO> getSectionsByBranch(Integer branchId) {
        return sectionRepository.findByBranchId(branchId).stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    public SectionDTO update(Integer id, SectionDTO dto) {
        Section section = sectionRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Section not found"));

        section.setName(dto.getName());
        section = sectionRepository.save(section);
        return mapToDTO(section);
    }

    public void delete(Integer id) {
        sectionRepository.deleteById(id);
    }

    private SectionDTO mapToDTO(Section section) {
        SectionDTO dto = new SectionDTO();
        dto.setId(section.getId());
        dto.setName(section.getName());
        dto.setBranchId(section.getBranch().getId());
        return dto;
    }
}
