package com.university.exam.dto;
import lombok.*;
@Data
public class InvigilatorAssignment {
    private Long roomId;
    private Long invigilatorId;
    public InvigilatorAssignment() {
    }
    public InvigilatorAssignment(Long roomId, Long invigilatorId) {
        this.roomId = roomId;
        this.invigilatorId = invigilatorId;
    }
    public Long getRoomId() {
        return roomId;
    }
    public void setRoomId(Long roomId) {
        this.roomId = roomId;
    }
    public Long getInvigilatorId() {
        return invigilatorId;
    }
    public void setInvigilatorId(Long invigilatorId) {
        this.invigilatorId = invigilatorId;
    }

}
