package com.university.exam.repository;

import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.university.exam.entity.Invigilator;
@Repository
public interface InvigilatorRepository extends JpaRepository<Invigilator, Long> {
}
