package com.university.exam.dto;

import lombok.*;
import java.sql.Timestamp;
import java.util.List;

@Data
@Builder
public class SeatingPlanDTO {
    private Long id;
    private Long examId;
    private Long blockId;
    private Long createdBy;
    private Timestamp createdAt;
    private List<Long> roomIds;
    private List<Long> sectionIds;

    public SeatingPlanDTO(Long id, Long examId, Long blockId, Long createdBy, Timestamp createdAt, List<Long> roomIds, List<Long> sectionIds) {
        this.id = id;
        this.examId = examId;
        this.blockId = blockId;
        this.createdBy = createdBy;
        this.createdAt = createdAt;
        this.roomIds = roomIds;
        this.sectionIds = sectionIds;
    }
    public SeatingPlanDTO() {
    }
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public Long getExamId() {
        return examId;
    }
    public void setExamId(Long examId) {
        this.examId = examId;
    }
    public Long getBlockId() {
        return blockId;
    }
    public void setBlockId(Long blockId) {
        this.blockId = blockId;
    }
    public Long getCreatedBy() {
        return createdBy;
    }
    public void setCreatedBy(Long createdBy) {
        this.createdBy = createdBy;
    }
    public Timestamp getCreatedAt() {
        return createdAt;
    }
    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
    public List<Long> getRoomIds() {
        return roomIds;
    }
    public void setRoomIds(List<Long> roomIds) {
        this.roomIds = roomIds;
    }
    public List<Long> getSectionIds() {
        return sectionIds;
    }
    public void setSectionIds(List<Long> sectionIds) {
        this.sectionIds = sectionIds;
    }
    public void setCreatedAt(java.util.Date createdAt) {
        this.createdAt = new Timestamp(createdAt.getTime());
    }

}
