package com.university.exam.dto;

import lombok.*;
@Data
@AllArgsConstructor
@Builder
public class BranchDTO {
    private Integer id;
    private String name;
    private Integer yearId;
    public BranchDTO(){

    }
    public BranchDTO(String name, Integer yearId) {
        this.name = name;
        this.yearId = yearId;
    }
    public BranchDTO(String name) {
        this.name = name;
    }
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public Integer getYearId() {
        return yearId;
    }
    public void setYearId(Integer yearId) {
        this.yearId = yearId;
    }
}
