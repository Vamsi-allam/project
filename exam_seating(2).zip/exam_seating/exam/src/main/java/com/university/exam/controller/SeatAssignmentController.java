package com.university.exam.controller;

import com.university.exam.dto.SeatAssignmentDTO;
import com.university.exam.service.SeatAssignmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/seat-assignments")
@CrossOrigin(origins = "*")
public class SeatAssignmentController {

    @Autowired
    private SeatAssignmentService seatAssignmentService;

    @PostMapping
    public ResponseEntity<SeatAssignmentDTO> create(@RequestBody SeatAssignmentDTO dto) {
        return ResponseEntity.ok(seatAssignmentService.createSeatAssignment(dto));
    }

    @GetMapping("/{id}")
    public ResponseEntity<SeatAssignmentDTO> getById(@PathVariable Long id) {
        return ResponseEntity.ok(seatAssignmentService.getSeatAssignment(id));
    }

    @GetMapping("/plan/{planId}")
    public ResponseEntity<List<SeatAssignmentDTO>> getByPlan(@PathVariable Long planId) {
        return ResponseEntity.ok(seatAssignmentService.getAssignmentsByPlan(planId));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        seatAssignmentService.deleteSeatAssignment(id);
        return ResponseEntity.noContent().build();
    }
}
