package com.university.exam.controller;

import com.university.exam.dto.StudentDTO;
import com.university.exam.entity.Section;
import com.university.exam.entity.Student;
import com.university.exam.repository.SectionRepository;
import com.university.exam.repository.StudentRepository;
import com.university.exam.service.ExcelImportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/students/import")
@CrossOrigin(origins = "*")
public class StudentUploadController {

    @Autowired
    private ExcelImportService excelImportService;

    @Autowired
    private StudentRepository studentRepo;

    @Autowired
    private SectionRepository sectionRepo;

    @PostMapping
    public ResponseEntity<Map<String, Object>> uploadExcel(
            @RequestParam("file") MultipartFile file,
            @RequestParam("yearId") Integer yearId,
            @RequestParam("branchId") Integer branchId,
            @RequestParam("sectionId") Integer sectionId
    ) {
        List<StudentDTO> studentDTOs = excelImportService.parseStudents(file, yearId, branchId, sectionId);

        Section section = sectionRepo.findById(sectionId)
                .orElseThrow(() -> new IllegalArgumentException("Section not found"));

        // Get existing registration numbers in the section
        Set<String> existingRegNos = studentRepo.findBySectionId(section.getId().longValue())
                .stream().map(Student::getRegNo).collect(Collectors.toSet());

        List<Student> toSave = new ArrayList<>();
        List<String> skipped = new ArrayList<>();

        for (StudentDTO dto : studentDTOs) {
            if (existingRegNos.contains(dto.getRegNo())) {
                skipped.add(dto.getRegNo());
                continue;
            }

            Student s = new Student();
            s.setRegNo(dto.getRegNo());
            s.setFullName(dto.getFullName());
            s.setSection(section);
            s.setBlocked(false);
            toSave.add(s);
        }

        studentRepo.saveAll(toSave);

        Map<String, Object> response = new HashMap<>();
        response.put("saved", toSave.size());
        response.put("skippedDuplicates", skipped.size());
        response.put("skippedRegNos", skipped);

        return ResponseEntity.ok(response);
    }
}
