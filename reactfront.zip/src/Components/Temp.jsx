import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './Temp.css';

const Temp = () => {
  const [temperature, setTemperature] = useState('');
  const [selectedAtm, setSelectedAtm] = useState('');
  const [type, setType] = useState('');
  const [atms, setAtms] = useState([]);
  const [cash100, setCash100] = useState('');
  const [cash200, setCash200] = useState('');
  const [cash500, setCash500] = useState('');

  // Add token configuration
  const token = localStorage.getItem('token');
  const config = {
    headers: {
      'Authorization': `Bearer ${token}`
    }
  };

  useEffect(() => {
    // Fetch ATMs from backend
    const fetchAtms = async () => {
      try {
        const response = await axios.get('http://localhost:2003/atm-details/atms', config);
        setAtms(response.data);
      } catch (error) {
        console.error('Error fetching ATMs:', error);
      }
    };
    fetchAtms();
  }, [token]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    let payload;
    let endpoint;
    
    if (type === "1") { // Cash
      endpoint = 'http://localhost:2003/api/sendcash';
      payload = {
        type: 1,
        atm: {
          atmId: parseInt(selectedAtm)
        },
        cash100: parseInt(cash100),
        cash200: parseInt(cash200),
        cash500: parseInt(cash500)
      };
    } else { // Temperature
      endpoint = 'http://localhost:2003/api/sendtemp';
      // Convert Kelvin to Celsius (K - 273.15)
      const tempInCelsius = parseFloat(temperature) - 273.15;
      payload = {
        temperature: tempInCelsius,
        atm: {
          atmId: parseInt(selectedAtm)
        },
        type: "2"
      };
    }

    try {
      await axios.post(endpoint, payload, config);
      alert('Data submitted successfully!');
      // Reset form
      setTemperature('');
      setSelectedAtm('');
      setType('');
      setCash100('');
      setCash200('');
      setCash500('');
    } catch (error) {
      console.error('Error submitting data:', error);
      alert('Error submitting data');
    }
  };

  return (
    <div className="card">
      <h2>ATM Data Form</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Type:</label>
          <select
            value={type}
            onChange={(e) => setType(e.target.value)}
            required
          >
            <option value="">Select Type</option>
            <option value="1">Cash</option>
            <option value="2">Temperature</option>
          </select>
        </div>

        <div className="form-group">
          <label>ATM:</label>
          <select
            value={selectedAtm}
            onChange={(e) => setSelectedAtm(e.target.value)}
            required
          >
            <option value="">Select ATM</option>
            {atms.map((atm, index) => (
              <option key={`${atm.atmId}-${index}`} value={atm.atmId}>
                {atm.atmId}
              </option>
            ))}
          </select>
        </div>

        {type === "2" && (
          <div className="form-group">
            <label>Temperature (in Kelvin):</label>
            <input
              type="number"
              value={temperature}
              onChange={(e) => setTemperature(e.target.value)}
              required
              placeholder="Enter temperature in Kelvin"
            />
          </div>
        )}

        {type === "1" && (
          <>
            <div className="form-group">
              <label>₹100 Notes:</label>
              <input
                type="number"
                value={cash100}
                onChange={(e) => setCash100(e.target.value)}
                required
              />
            </div>
            <div className="form-group">
              <label>₹200 Notes:</label>
              <input
                type="number"
                value={cash200}
                onChange={(e) => setCash200(e.target.value)}
                required
              />
            </div>
            <div className="form-group">
              <label>₹500 Notes:</label>
              <input
                type="number"
                value={cash500}
                onChange={(e) => setCash500(e.target.value)}
                required
              />
            </div>
          </>
        )}

        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default Temp;