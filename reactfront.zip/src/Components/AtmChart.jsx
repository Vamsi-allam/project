import React, { useState, useEffect } from "react";
import { Bar } from "react-chartjs-2";
import "chart.js/auto";
import "../Components/AtmChart.css"; // Custom CSS for styling

const AtmChart = () => {
  const [atmData, setAtmData] = useState([]);
  const [loading, setLoading] = useState(true);
  const token = localStorage.getItem("token");

  useEffect(() => {
    fetch("http://127.0.0.1:2003/locations", {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    })
      .then((response) => response.json())
      .then((data) => {
        const processedData = [];

        data.forEach((location) => {
          location.branches.forEach((branch) => {
            branch.atms.forEach((atm) => {
              if (atm.status === "Active") {
                const totalCashLogs = atm.cash.length;
                const totalTempLogs = atm.temp.length;

                processedData.push({
                  atmCode: atm.atmCode,
                  transactions: totalCashLogs + totalTempLogs,
                });
              }
            });
          });
        });

        setAtmData(processedData);
        setLoading(false);
      })
      .catch((error) => {
        console.error("Error fetching ATM transaction data:", error);
        setLoading(false);
      });
  }, [token]);

  if (loading) return <p className="chart-loading-text">Loading chart...</p>;

  const chartData = {
    labels: atmData.map((atm) => atm.atmCode),
    datasets: [
      {
        label: "Number of Incoming Transactions",
        data: atmData.map((atm) => atm.transactions),
        backgroundColor: "rgba(54, 162, 235, 0.6)",
        borderColor: "rgba(54, 162, 235, 1)",
        borderWidth: 1,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      y: { beginAtZero: true },
    },
  };

  return (
    <div className="atm-chart-container">
      <h3>ATM Incoming Transactions</h3>
      <div className="chart-wrapper">
        <Bar data={chartData} options={options} />
      </div>
    </div>
  );
};

export default AtmChart;
