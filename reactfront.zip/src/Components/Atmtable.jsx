import React, { useState, useEffect } from "react";
import axios from "axios";
import {
  FaMapMarkerAlt,
  FaBuilding,
  FaCreditCard,
  FaToggleOn,
  FaToggleOff,
  FaPlus,
} from "react-icons/fa";
import "../Components/Atmtable.css";

const AtmTable = () => {
  const [atms, setAtms] = useState([]);
  const [locations, setLocations] = useState([]);
  const [branches, setBranches] = useState([]);
  const [selectedLocation, setSelectedLocation] = useState("");
  const [selectedBranch, setSelectedBranch] = useState("");
  const [atmCode, setAtmCode] = useState("");
  const [atmStatus, setAtmStatus] = useState("Active");
  const [showPopup, setShowPopup] = useState(false);
  const token = localStorage.getItem("token");
  const isDarkMode = localStorage.getItem("theme") === "dark";

  // Fetch Locations & ATMs
  useEffect(() => {
    axios
      .get("http://127.0.0.1:2003/locations", {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then((response) => {
        setLocations(response.data);
        const formattedData = response.data.flatMap((location) =>
          location.branches.flatMap((branch) =>
            branch.atms.map((atm) => ({
              locationName: location.name,
              branchName: branch.branchName,
              atmId: atm.atmId,
              atmCode: atm.atmCode,
              status: atm.status,
            }))
          )
        );
        setAtms(formattedData);
      })
      .catch((error) => console.error("Error fetching data:", error));
  }, []);

  // Handle Location Change
  const handleLocationChange = (e) => {
    const locationId = parseInt(e.target.value, 10);
    setSelectedLocation(locationId);
    setSelectedBranch(""); // Reset branch when location changes

    const selectedLoc = locations.find((loc) => loc.locationId === locationId);
    setBranches(selectedLoc ? selectedLoc.branches : []);
  };

  // Handle Add ATM
  const handleAddAtm = () => {
    if (!selectedBranch || !atmCode) {
      alert("Please fill all fields");
      return;
    }

    axios
      .post(
        `http://127.0.0.1:2003/atm-details/branches/${selectedBranch}/atms`,
        { atmCode, status: atmStatus },
        { headers: { Authorization: `Bearer ${token}` } }
      )
      .then(() => {
        alert("ATM Added Successfully!");
        setShowPopup(false);
        setAtmCode("");
        setAtmStatus("Active");
      })
      .catch((error) => console.error("Error adding ATM:", error));
  };

  const handleToggleStatus = (atmId, currentStatus) => {
    const newStatus = currentStatus === "Active" ? "Inactive" : "Active";

    axios
      .put(
        `http://127.0.0.1:2003/api/atms/${atmId}`,
        { status: newStatus },
        { headers: { Authorization: `Bearer ${token}` } }
      )
      .then(() => {
        // Update only the specific ATM, without modifying others
        setAtms((prevAtms) =>
          prevAtms.map((atm) =>
            atm.atmId === atmId ? { ...atm, status: newStatus } : atm
          )
        );
      })
      .catch((error) => console.error("Error updating ATM status:", error));
  };

  return (
    <div className={`atm-table-container ${isDarkMode ? "dark-mode" : ""}`}>
      <div className="atm-header">
        <h2 className="atm-table-title">ATM List</h2>
        <button className="add-atm-btn" onClick={() => setShowPopup(true)}>
          <FaPlus /> Add ATM
        </button>
      </div>

      <table className="atm-table-custom">
        <thead>
          <tr>
            <th>
              <FaMapMarkerAlt size={16} /> Location
            </th>
            <th>
              <FaBuilding size={16} /> Branch
            </th>
            <th>
              <FaCreditCard size={16} /> ATM Code
            </th>
            <th>Status</th>
            <th>Toggle</th>
          </tr>
        </thead>
        <tbody>
          {atms.map((atm) => (
            <tr key={`${atm.branchId}-${atm.atmId}`}>
              {" "}
              {/* Ensures uniqueness */}
              <td>{atm.locationName}</td>
              <td>{atm.branchName}</td>
              <td>{atm.atmCode}</td>
              <td
                className={
                  atm.status === "Active"
                    ? "atm-status-active"
                    : "atm-status-inactive"
                }
              >
                {atm.status}
              </td>
              <td>
                <button
                  className="atm-toggle-switch"
                  onClick={() => handleToggleStatus(atm.atmId, atm.status)}
                >
                  {atm.status === "Active" ? (
                    <FaToggleOn size={30} color="green" />
                  ) : (
                    <FaToggleOff size={30} color="red" />
                  )}
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {showPopup && (
        <div className="popup-overlay">
          <div className="popup-box">
            <h3>Add New ATM</h3>
            <label>Location</label>
            <select value={selectedLocation} onChange={handleLocationChange}>
              <option value="">Select Location</option>
              {locations.map((loc) => (
                <option key={loc.locationId} value={loc.locationId}>
                  {loc.name}
                </option>
              ))}
            </select>

            <label>Branch</label>
            <select
              value={selectedBranch}
              onChange={(e) => setSelectedBranch(parseInt(e.target.value, 10))}
              disabled={!selectedLocation}
            >
              <option value="">Select Branch</option>
              {branches.map((branch) => (
                <option
                  key={`${selectedLocation}-${branch.branchId}`}
                  value={branch.branchId}
                >
                  {branch.branchName}
                </option>
              ))}
            </select>

            <label>ATM Code</label>
            <input
              type="text"
              value={atmCode}
              onChange={(e) => setAtmCode(e.target.value)}
            />

            <label>Status</label>
            <button
              className="atm-toggle-switch"
              onClick={() =>
                setAtmStatus(atmStatus === "Active" ? "Inactive" : "Active")
              }
            >
              {atmStatus === "Active" ? (
                <FaToggleOn size={30} color="green" />
              ) : (
                <FaToggleOff size={30} color="red" />
              )}
            </button>

            <div className="popup-buttons">
              <button onClick={handleAddAtm}>Submit</button>
              <button onClick={() => setShowPopup(false)}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AtmTable;
