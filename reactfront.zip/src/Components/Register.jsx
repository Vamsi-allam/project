import React, { useState, useEffect } from "react";
 
import { useNavigate } from "react-router-dom";
 
import Snackbar from "@mui/material/Snackbar";
 
import Alert from "@mui/material/Alert";
 
import "../Components/Register.css"; // CSS file import
 
const Registration = () => {
 
 useEffect(() => {
 
  // Fix page: no scrolling and zero margin
 
  document.body.style.margin = "0";
 
  document.body.style.overflow = "hidden";
 
  return () => {
 
   document.body.style.margin = "";
 
   document.body.style.overflow = "";
 
  };
 
 }, []);
 
 const [name, setName] = useState("");
 
 const [email, setEmail] = useState("");
 
 const [phonenumber, setPhonenumber] = useState("");
 
 const [password, setPassword] = useState("");
 
 const [confirmPassword, setConfirmPassword] = useState("");
 
 const [role, setRole] = useState("");
 
 const [showPassword, setShowPassword] = useState(false);
 
 const [emailError, setEmailError] = useState("");
 
 const [phoneError, setPhoneError] = useState("");
 
 const [passwordError, setPasswordError] = useState("");
 
 const [confirmPasswordError, setConfirmPasswordError] = useState("");
 
 const navigate = useNavigate();
 
 const validateEmail = () => {
 
  if (!email.includes("@")) {
 
   setEmailError("Invalid email address");
 
  } else {
 
   setEmailError("");
 
  }
 
 };
 
 const validatePhoneNumber = () => {
 
  const phoneRegex = /^[0-9]{10}$/;
 
  if (!phoneRegex.test(phonenumber)) {
 
   setPhoneError("Phone number must be 10 digits");
 
  } else {
 
   setPhoneError("");
 
  }
 
 };
 
 const validatePassword = () => {
 
  const passwordRegex =
 
   /^(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{4,12}$/;
 
  if (!passwordRegex.test(password)) {
 
   setPasswordError(
 
    "Password must be 4-12 characters, include at least one capital letter, one number, and one special character."
 
   );
 
  } else {
 
   setPasswordError("");
 
  }
 
 };
 
 const validateConfirmPassword = () => {
 
  if (password !== confirmPassword) {
 
   setConfirmPasswordError("Passwords do not match");
 
  } else {
 
   setConfirmPasswordError("");
 
  }
 
 };
 
 // Material UI Snackbar state for alerts
 
 const [snackbarOpen, setSnackbarOpen] = useState(false);
 
 const [snackbarData, setSnackbarData] = useState({
 
  message: "",
 
  severity: "success",
 
 });
 
 const handleSnackbarClose = (event, reason) => {
 
  if (reason === "clickaway") return;
 
  setSnackbarOpen(false);
 
 };
 
 const handleSubmit = async (e) => {
 
  e.preventDefault();
 
  validateEmail();
 
  validatePhoneNumber();
 
  validatePassword();
 
  validateConfirmPassword();
 
  // Check if any validation errors exist
 
  if (emailError || phoneError || passwordError || confirmPasswordError) {
 
   return;
 
  }
 
  try {
 
   const response = await fetch("http://localhost:2003/auth/register", {
 
    method: "POST",
 
    headers: {
 
     "Content-Type": "application/json",
 
    },
 
    body: JSON.stringify({
 
     name,
 
     email,
 
     phonenumber,
 
     password,
 
     role,
 
    }),
 
   });
 
   const isJson = response.headers
 
    .get("content-type")
 
    ?.includes("application/json");
 
   if (response.ok) {
 
    const data = isJson ? await response.json() : await response.text();
 
    // Show success alert
 
    setSnackbarData({
 
     message: `${data.message || "Registration successful!"} as ${role}`,
 
     severity: "success",
 
    });
 
    setSnackbarOpen(true);
 
    // After 2 seconds, update alert to navigation info
 
    setTimeout(() => {
 
     setSnackbarData({
 
      message: "Navigating to login...",
 
      severity: "info",
 
     });
 
     setSnackbarOpen(true); // Ensure the Snackbar is open
 
     // Navigate after another 2 seconds
 
     setTimeout(() => navigate("/login"), 2000);
 
    }, 2000);
 
   } else {
 
    const errorData = isJson ? await response.json() : await response.text();
 
    setSnackbarData({
 
     message: errorData.error || "Registration failed.",
 
     severity: "error",
 
    });
 
    setSnackbarOpen(true);
 
   }
 
  } catch (error) {
 
   console.error("Error:", error);
 
   setSnackbarData({
 
    message: "An error occurred. Please try again.",
 
    severity: "error",
 
   });
 
   setSnackbarOpen(true);
 
  }
 
 };
 
 return (
 
  <>
 
   <div className="reg-container">
 
    {/* Navigation Bar */}
 
    <nav className="reg-navbar">
 
     <div className="reg-brand">ATM-MONITORING</div>
 
     <div className="reg-nav-buttons">
 
      <button onClick={() => navigate("/")} className="reg-nav-button">
 
       HomePage
 
      </button>
 
      <button onClick={() => navigate("/login")} className="reg-nav-button">
 
       Login
 
      </button>
 
     </div>
 
    </nav>
 
    <div className="reg-box">
 
     <div className="reg-header">
 
      <h2 className="reg-heading">Welcome!</h2>
 
      <p className="reg-subheading">Register here to access the account</p>
 
     </div>
 
     <form onSubmit={handleSubmit} className="reg-form">
 
      {/* Name and Email Fields Side by Side */}
 
      <div className="reg-row">
 
       <div className="reg-input-container">
 
        <label className="reg-label">Name</label>
 
        <input
 
         type="text"
 
         placeholder="Enter your name"
 
         value={name}
 
         onChange={(e) => setName(e.target.value)}
 
         required
 
         className="reg-input"
 
        />
 
       </div>
 
       <div className="reg-input-container">
 
        <label className="reg-label">Email</label>
 
        <input
 
         type="email"
 
         placeholder="name@example.com"
 
         value={email}
 
         onChange={(e) => setEmail(e.target.value)}
 
         onBlur={validateEmail}
 
         required
 
         className="reg-input"
 
        />
 
        {emailError && <p className="reg-error">{emailError}</p>}
 
       </div>
 
      </div>
 
      {/* Phone Number Field */}
 
      <div className="reg-input-container">
 
       <label className="reg-label">Phone Number</label>
 
       <input
 
        type="text"
 
        placeholder="Enter your phone number"
 
        value={phonenumber}
 
        onChange={(e) => setPhonenumber(e.target.value)}
 
        onBlur={validatePhoneNumber}
 
        required
 
        className="reg-input"
 
       />
 
       {phoneError && <p className="reg-error">{phoneError}</p>}
 
      </div>
 
      {/* Password and Confirm Password Side by Side */}
 
      <div className="reg-row">
 
       <div className="reg-input-container">
 
        <label className="reg-label">Password</label>
 
        <input
 
         type={showPassword ? "text" : "password"}
 
         placeholder="Enter password"
 
         value={password}
 
         onChange={(e) => setPassword(e.target.value)}
 
         onBlur={validatePassword}
 
         required
 
         className="reg-input"
 
        />
 
        {passwordError && <p className="reg-error">{passwordError}</p>}
 
       </div>
 
       <div className="reg-input-container">
 
        <label className="reg-label">Confirm Password</label>
 
        <input
 
         type={showPassword ? "text" : "password"}
 
         placeholder="Confirm password"
 
         value={confirmPassword}
 
         onChange={(e) => setConfirmPassword(e.target.value)}
 
         onBlur={validateConfirmPassword}
 
         required
 
         className="reg-input"
 
        />
 
        {confirmPasswordError && (
 
         <p className="reg-error">{confirmPasswordError}</p>
 
        )}
 
       </div>
 
      </div>
 
      {/* Show Password Checkbox */}
 
      <div className="reg-show-password-container">
 
       <label className="reg-show-password-label">
 
        <input
 
         type="checkbox"
 
         checked={showPassword}
 
         onChange={() => setShowPassword(!showPassword)}
 
         className="reg-checkbox"
 
        />{" "}
 
        Show Password
 
       </label>
 
      </div>
 
      {/* Role Selection */}
 
      <div className="reg-input-container">
 
       <label className="reg-label">Role</label>
 
       <div className="reg-radio-container">
 
        <label className="reg-radio-label">
 
         <input
 
          type="radio"
 
          name="role"
 
          value="ADMIN"
 
          onChange={(e) => setRole(e.target.value)}
 
          required
 
          className="reg-radio-button"
 
         />{" "}
 
         Admin
 
        </label>
 
        <label className="reg-radio-label">
 
         <input
 
          type="radio"
 
          name="role"
 
          value="TECHNICIAN"
 
          onChange={(e) => setRole(e.target.value)}
 
          required
 
          className="reg-radio-button"
 
         />{" "}
 
         Technician
 
        </label>
 
       </div>
 
      </div>
 
      {/* Register Button */}
 
      <button type="submit" className="reg-button">
 
       Register
 
      </button>
 
     </form>
 
     {/* Already Have an Account */}
 
     <p className="reg-already-text">
 
      Already have an account?{" "}
 
      <span className="reg-link" onClick={() => navigate("/login")}>
 
       Login here
 
      </span>
 
     </p>
 
    </div>
 
   </div>
 
   {/* Material UI Snackbar with Alert */}
 
   <Snackbar
 
    open={snackbarOpen}
 
    autoHideDuration={5000} // Increased duration
 
    onClose={handleSnackbarClose}
 
    anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
 
   >
 
    <Alert
 
     onClose={handleSnackbarClose}
 
     severity={snackbarData.severity}
 
     variant="filled"
 
     sx={{ width: "100%" }}
 
    >
 
     {snackbarData.message}
 
    </Alert>
 
   </Snackbar>
 
  </>
 
 );
 
};
 
export default Registration;