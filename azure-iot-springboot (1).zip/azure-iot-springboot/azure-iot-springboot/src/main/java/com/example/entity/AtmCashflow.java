package com.example.entity;


import com.google.gson.Gson;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import lombok.*;
import jakarta.persistence.Transient;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Entity
public class AtmCashflow {
    @Id

    @GeneratedValue(strategy = GenerationType.IDENTITY)

    @Column(name = "cashflow_id")

    private int cashFlowId;

    @Column(name = "cash100")

    private int cash100;

    @Column(name = "cash200")

    private int cash200;

    @Column(name = "cash500")

    private int cash500;

    @Column(name = "updated_at", nullable = false)

    private String updatedAt;

    @ManyToOne

    @JoinColumn(name = "atm_id", nullable = false)

    private Atm atm;
    
    @Transient
    private int type;

    public String serialize() {
        Gson gson = new Gson();
        return gson.toJson(this);
    }


    // Getters and Setters
}
