package com.example.controller;

import lombok.RequiredArgsConstructor;

import org.springframework.security.crypto.password.PasswordEncoder;

import org.springframework.web.bind.annotation.*;

import com.example.dto.AuthRequest;
import com.example.dto.JwtResponse;
import com.example.dto.RegisterRequest;
import com.example.repository.UserRepository;
import com.example.service.JwtService;

import com.example.entity.User;

@RestController
@CrossOrigin("*")
@RequestMapping("/auth")

@RequiredArgsConstructor

public class AuthController {

  private final UserRepository userRepository;

  private final PasswordEncoder passwordEncoder;

  private final JwtService jwtService;

  @PostMapping("/register")

  public String register(@RequestBody RegisterRequest request) {
    if (userRepository.existsByEmail(request.getEmail())) {
      throw new IllegalArgumentException("Email already exists");
  }

  if (userRepository.existsByPhonenumber(request.getPhonenumber())) {
      throw new IllegalArgumentException("Phone number already exists");
  }

    User user = User.builder()

        .name(request.getName())
        .email(request.getEmail())
        .phonenumber(request.getPhonenumber())

        .password(passwordEncoder.encode(request.getPassword()))

        .role(request.getRole())

        .build();

    userRepository.save(user);

    return "User registered successfully";

  }

  @PostMapping("/login")
  public JwtResponse login(@RequestBody AuthRequest request) {
    User user = userRepository.findByEmail(request.getEmail())
        .orElseGet(() -> userRepository.findByPhonenumber(request.getPhonenumber())
        .orElseThrow(() -> new RuntimeException("User not found")));

    if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
      throw new RuntimeException("Invalid credentials");
    }

    String token = jwtService.generateToken(user.getEmail());
    return new JwtResponse(token, user.getName(), user.getEmail(), user.getPhonenumber(), user.getRole().name());
  }

}