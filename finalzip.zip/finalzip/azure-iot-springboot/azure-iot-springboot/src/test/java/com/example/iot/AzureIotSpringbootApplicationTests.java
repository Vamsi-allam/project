package com.example.iot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AzureIotSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
